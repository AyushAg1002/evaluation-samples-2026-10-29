Investigate case `IR-2026-0417` using `/app/evidence/case_brief.md`, `/app/evidence/network_transfer_protocol.md`, `/app/evidence/inside_sensor.pcap`, `/app/evidence/edge_sensor.pcap`, `/app/evidence/firewall_nat.csv`, `/app/evidence/asset_inventory.csv`, `/app/evidence/sensor_clock_calibration.csv`, and `/app/evidence/tls_session_keys.log`. The inside and edge captures contain complementary gaps. Recover the unique NFX2 object whose manifest marks it as a restricted export, and identify the network session that carried it.

The observable success criteria are:

1. Create `/app/recovered/exfiltrated.bin` and `/app/incident_report.json` as regular files beneath `/app`; symlinks are not accepted.

2. `/app/recovered/exfiltrated.bin` must contain the exact bytes of the restricted-export object after TCP, TLS, HTTP/2, and NFX2 reassembly.

3. `/app/incident_report.json` must be a JSON object with exactly these keys: `case_id`, `victim`, `nat`, `destination`, `tls_client_random`, `object`, `reassembly`, and `transfer`. The nested objects may contain only the fields specified below, with no extra fields at any level.

4. `case_id` must be `IR-2026-0417`. `victim` must contain exactly the string fields `ip`, `mac`, and `hostname` for the pre-NAT source. `nat` must contain exactly `public_ip` as a string and `public_port` as an integer. `destination` must contain exactly `ip` as a string, `port` as an integer, and `sni` as a string. `tls_client_random` must be the lowercase 64-hex-character ClientHello random for the recovered object's session.

5. `object` must contain exactly `name`, `size_bytes`, `sha256`, and `chunk_count`. `name` and lowercase `sha256` are strings; `size_bytes` and `chunk_count` are integers. These values must describe `/app/recovered/exfiltrated.bin` and its NFX2 manifest exactly.

6. `reassembly` must contain exactly the integer fields `client_stream_bytes`, `shared_bytes`, `inside_only_bytes`, and `edge_only_bytes`, describing the client-to-server application byte stream of the recovered object's TCP session — that is, the TLS stream you reassembled, before decryption.

   Define them over the stream's byte offsets, counting each offset once:

   - `client_stream_bytes` is the length of that reassembled stream in bytes.
   - `shared_bytes` is the number of its offsets carried by a segment present in **both** captures.
   - `inside_only_bytes` is the number carried by a segment present in the inside capture but **not** the edge capture.
   - `edge_only_bytes` is the number carried by a segment present in the edge capture but **not** the inside capture.

   A segment counts as present in a capture if that capture contains it at all, including as a retransmission. The three classes partition the stream, so they must sum to `client_stream_bytes`.

7. `transfer` must contain exactly `first_chunk_utc`, `last_chunk_utc`, and `chunk_utc`. The first two are UTC timestamps formatted as `YYYY-MM-DDTHH:MM:SS.ffffffZ`. `chunk_utc` is an array of timestamps in that same format, in ascending order, holding **one observation time for every chunk** of the recovered object — so its length equals `object.chunk_count`, and its first and last entries equal `first_chunk_utc` and `last_chunk_utc`. Compute every one of them using the timestamp rule in `/app/evidence/network_transfer_protocol.md`, including its instruction on which observation to use when both sensors captured the byte. Values within 10 milliseconds of the evidence-derived times are accepted.

All evidence needed to solve the case is supplied locally. Preserve the evidence and derive the result from the documented captures, mappings, calibration records, and protocol description.
