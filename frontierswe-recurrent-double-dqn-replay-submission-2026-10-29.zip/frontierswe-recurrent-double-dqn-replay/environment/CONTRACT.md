# Recurrent learner checkpoint contract

This file is normative. `/app/data/learner_snapshot.json` contains a synthetic
checkpoint and replay segments captured at a learner pause. Reproduce the next
three minibatch updates independently for each entry in `cases`. The starting
online network, target network, optimizer, and raw replay priorities are reset to
the snapshot at the beginning of each case. The batches within a case are ordered
and share the state produced by preceding updates.

## Network and replay

All tensors use row-vector conventions and have their shapes encoded by the
nested arrays. For observation `x` and preceding recurrent state `h_prev`:

```
e1 = ReLU(x @ W1 + b1)
e2 = ReLU(e1 @ W2 + b2)
h = tanh(e2 @ Wx + h_prev @ Wh + bh)
value = h @ Wv + bv
advantage = h @ Wa + ba
Q = value + advantage - center(advantage)
```

Both hidden affine encoder layers have ReLU, including the layer using `W2`.
The recurrent activation is tanh. There are no other activations. `center` is the
mean across **all** actions for `advantage_aggregation="mean"`, and the maximum
across all actions for `"max"`. Action masks affect bootstrap action selection
only. At a maximum tie, the lowest action index wins (also for the derivative).
ReLU's derivative at zero is zero. All parameters, including biases and both
encoder layers, are trainable online parameters.

Each replay segment has `observations` of length T+1, and `actions`, `rewards`,
`terminated`, `truncated`, and `legal_actions` of length T. `legal_actions[t]`
describes the allowed actions at `observations[t+1]`. Segments stay within an
episode; an end flag, if present, occurs only on its last transition. The last
observation of a truncated segment is the actual final observation before reset.
It is never the observation of a new episode. An unflagged segment can end because
the replay extraction reached its look-ahead limit.

`online_hidden` and `target_hidden` are distinct saved hidden states **before**
`observations[0]`. Each network starts from its own saved state and consumes
observations in order using its own weights. `burn_in` is the number of initial
transitions used only to reconstruct recurrent state. Learning positions are
`burn_in .. burn_in+learn_length-1`. Padding is not stored. Sequence lengths and
burn-in lengths differ. When a segment appears again, its recurrent state must
be reconstructed with the then-current parameters and its original saved state.

## Targets, loss, and gradients

For every learning position t, accumulate up to `n_step` rewards clipped
individually to `[-reward_clip, reward_clip]`. Stop at an end flag or the segment
end. If K rewards were consumed, their discounted sum uses exponents 0 through
K-1. Add `gamma**K` times the Double-DQN bootstrap at observation t+K unless the
last consumed transition was terminated. Truncation and unflagged segment end
both bootstrap. The online network selects the largest Q among the last
consumed transition's legal actions; the target network evaluates that action.
Both Q vectors use their own recurrent history up to that observation. Call this
target `n_step_return`, and define `td_error = n_step_return - Q_online(t,action[t])`.

The loss is the batch mean of each draw's IS weight times its mean Huber loss
over learning positions. For error d, Huber is `0.5*d*d` when `abs(d)<=huber_delta`,
and `huber_delta*(abs(d)-0.5*huber_delta)` otherwise. Different sequence lengths
do not change this per-sequence normalization. A repeated sequence in a batch is
a separate draw and contributes again to the loss.

Targets, IS weights, saved hidden states, and replay priorities are constants for
this gradient. The online hidden state **after the last burn-in observation** is
also detached: the loss differentiates through the learning observations and
their recurrent connections, but never through burn-in. A zero burn-in detaches
the saved hidden state. No gradient passes through any bootstrap or target
computation, even where it uses the online network. All quantities are evaluated
at the parameters before this update.

## Replay and update state

At the start of an update the full replay table contains raw positive priorities
p. Sampling masses are `p**alpha`. Conventional PER weights `(N*P)**(-beta)` are
normalized by the maximum within the sampled batch, where P is full-table
sampling probability. This is equivalent to `p**(-alpha*beta)` divided by its
batch maximum. `priority_power` does not affect sampling weights.

For each draw let `raw = priority_epsilon + priority_mix*max(abs(td_error)) +
(1-priority_mix)*mean(abs(td_error))`, using all its learning positions before the
optimizer update. Its reported `new_priority` is `raw**alpha` when
`priority_power=true`, and `raw` otherwise. The replay table always stores raw
priorities. After the update replace sampled entries with raw values, taking the
maximum raw value if an entry was sampled more than once. Unsampled entries stay
unchanged. Those resulting priorities determine the **next** batch's weights.

`gradient_norm` is the L2 norm of the entire unscaled loss gradient over all
online parameters. Scale the entire gradient by
`min(1, grad_clip / gradient_norm)` (use 1 if the norm is zero).
Resume the supplied AdamW state. Increment its integer `step` once per batch;
update moments using `beta1` and `beta2` with the clipped gradient, apply bias
correction using the incremented global step, and use
`sqrt(v_hat) + adam_epsilon` in the denominator. Every parameter, including
biases, becomes `(1-lr*weight_decay)*old_parameter - lr*m_hat/(sqrt(v_hat)+adam_epsilon)`.
Moments are the uncorrected moments; do not reset them between cases except to
the provided snapshot. If the incremented step is divisible by `target_interval`,
set every target tensor to `(1-tau)*old_target + tau*new_online`. Otherwise the
target network is unchanged. Each subsequent batch sees this updated state.

## Meta-gradient continuation

In addition to the ordinary checkpoints at the supplied inputs, reproduce this
runtime's nested differentiation policy. These are derivatives of a specified
replay calibration program, not unrestricted numerical derivatives of the
ordinary update script. At the outer level, `SG(z)` preserves z's value and is a
constant for derivatives of **every positive order**; differentiating again must
not restore a dependence that was stopped. No input is missing:
`meta.directions`, `meta.curvature_directions` and `meta.validation` are part of
the snapshot. The required evaluation point is the all-zero vector
of nine real controls, in `meta.control_order`:

| Control | Modification at the start of each case |
| --- | --- |
| `log_learning_rate` | Multiply that case's lr by exp(control). |
| `reward_shift` | Add control times `directions.rewards[id]` to each segment's rewards, before reward clipping. |
| `alpha_shift` | Add control to that case's alpha. |
| `online_shift` | Add control times `directions.online[name]` to each initial online tensor. |
| `moment_shift` | Add control times `directions.m[name]` to each initial uncorrected first-moment tensor. |
| `log_priority_shift` | Multiply each initial raw priority by exp(control times `directions.priorities[id]`). |
| `hidden_shift` | Add control times `directions.online_hidden[id]` and `directions.target_hidden[id]` to the respective saved recurrent seeds. |
| `target_shift` | Add control times `directions.target[name]` to each initial target tensor. |
| `discount_shift` | Replace gamma by `sigmoid(log(gamma/(1-gamma)) + control)`, where `sigmoid(z)=1/(1+exp(-z))`. |

All other starting quantities are fixed. These perturbations are simultaneous;
they are applied only once before the three updates, not again at each update.
The raw priorities and optimizer state then evolve as already specified.

There are two distinct differentiation levels:

1. At each update, the **local** gradient is exactly the earlier semi-gradient:
   differentiate the Huber loss with respect to a fresh local copy of the current
   online parameters. Burn-in state, targets and IS weights are constant with
   respect to that local copy; recurrent connections *inside* the learning
   window remain differentiable. This gradient supplies the optimizer update.
2. For the **outer** derivative with respect to the nine controls, differentiate
   the computation that produced that local gradient, and the subsequent
   optimizer/replay updates, through all three batches. A local constant can
   still depend on a control. In particular, the reconstructed burn-in state,
   unclipped rewards, IS numerators, raw priority replacements, optimizer
   moments and previous online parameters keep their outer dependence.

Exactly three sites **within the learner update** are stopped at the outer level:

- The selected target-network bootstrap Q scalar is replaced by `SG(Q_target)`
  before multiplication by gamma**K. Clipped reward sums remain live.
- Define each IS numerator specifically as `u=p**(-alpha*beta)`; use
  `weight = u / SG(max_batch(u))`. Differentiating an equivalent full-table
  probability expression with its own stopped denominator is not this policy.
- The clipping multiplier is
  `SG(min(1, grad_clip / gradient_norm))`, or SG(1) for zero norm. The raw
  local gradient entering that multiplication retains its outer dependence.

There are no other outer stops within the learner. In particular, do not detach the entire return,
the burn-in state, IS weights, local gradient, moments, raw priorities, or the
updated online tensors at the outer level. Do not replace the local semi-gradient
with a full gradient through bootstraps or burn-in. All derivatives are evaluated
at zero controls; discrete indices and boolean decisions are not differentiated.
For this differentiation, abs has derivative zero at zero; reward clipping has
derivative one inside and at its bounds, zero outside; Huber uses the quadratic branch at
the threshold. The earlier ReLU and maximum tie rules also apply.

Define V(theta) by evaluating the online network independently on each
`meta.validation` sequence from its fixed `hidden` state, consuming all of its
observations. V is the unweighted mean of `(Q[action]-returns)**2` over **all**
validation positions across all sequences. Evaluate V with that case's
`advantage_aggregation`, exactly as the learner does. The supplied returns are calibration
inputs, not expected checkpoint outputs. Neither V nor its recurrent history is
detached. `validation_loss` is V after the third update.

## Replay calibration and curvature

The listed batches are one observed trace of independent sampling **with
replacement** at each update. Do not generate different draws or average over
other possible traces. At stage k (zero-based), let p_k be the full raw replay
table **before** this update. Each draw i has probability

`P_k(i) = p_k[i]**alpha / sum_j(p_k[j]**alpha)`,

where j ranges over every replay ID, including unsampled entries. Define
`ell_k = sum_i log(P_k(i))` over the ordered batch, counting every duplicate.
All draws in a batch use the same starting table. This probability denominator
is **live**, unlike the stopped IS denominator inside the learner.
Let `L_k = sum_{r=0}^k ell_r`, with `L_-1=0`. Updated priorities and alpha
retain their outer dependence in these likelihoods.

Write theta_k for the online parameters before update k and theta_(k+1) for
those after it. For K=3 updates define `B_k=V(theta_k)/K` and
`C_k=V(theta_(k+1))/K`. B is evaluated before the current update; its control
dependence is not stopped. Define `M(z)=exp(z-SG(z))`. The canonical scalar
program whose derivatives are requested is exactly

`D = sum_{k=0}^{K-1} [M(L_k)*C_k + (M(L_(k-1))-M(L_k))*B_k]`.

Use the earlier learner-level stops and local-gradient boundary inside this
program. M's SG has zero derivatives at every positive outer order. Its value
is one, but M must not be replaced by the constant one when differentiating.
There are no further stops on C, B, likelihood prefixes or their inputs.
This equation, rather than an arbitrary first-order-equivalent surrogate,
defines the required higher-order derivatives.

At the zero-control evaluation point, report `replay_loss = D`,
`hypergradient[name] = partial D / partial control[name]`, and
`curvature[probe_id] = H @ v`, where H is the 9-by-9 outer Hessian of D
and v is that probe's vector from `meta.curvature_directions`.
Each product is a nine-element array in `meta.control_order`.
The controls perturb the initial state once, while differentiation traverses
all three updates and their causally ordered sampling likelihoods.

## Required artifact

Write `/app/output/batch_results.json` as a regular UTF-8 JSON file with no
symlinks in its path. Its only top-level key is `cases`, an array in input case
order. Each case has exactly `id`, `updates`, and `meta`. `meta` has exactly
`validation_loss` and `replay_loss` (scalars), `hypergradient` (a dictionary
with exactly the nine control names and scalar partial derivatives), and
`curvature` (a dictionary with exactly the input curvature probe IDs and their
nine-element Hessian-vector products). Each update
has exactly:

- `step`: the incremented optimizer step (integer).
- `draws`: input batch order, each object with exactly `draw` (zero-based integer
  ordinal), `sequence_id` (input ID), `n_step_return` and `td_error` (arrays in
  learning-position order), `is_weight`, and `new_priority`.
- `loss` and `gradient_norm`: scalars before clipping and optimization.
- `online` and `target`: parameter dictionaries with exactly the snapshot's
  tensor names and shapes, containing the values after the update.
- `optimizer`: exactly `step`, `m`, `v`; dictionaries m and v have the same tensor
  names and shapes as the online network, with uncorrected moments after updating.
- `priorities`: the full ID-to-raw-priority table after this batch.

All noninteger numeric fields must be finite JSON numbers. No extra fields are
allowed; object key order and whitespace are immaterial. Values are compared
with absolute tolerance 1e-6 plus relative tolerance 1e-5 times the expected
magnitude, except curvature entries, which use absolute tolerance 2e-5 plus
relative tolerance 2e-4. These tolerances allow numerical differentiation;
no implementation method, source text or particular library is required.
Verification reads this saved artifact only; it does not execute submitted code.
