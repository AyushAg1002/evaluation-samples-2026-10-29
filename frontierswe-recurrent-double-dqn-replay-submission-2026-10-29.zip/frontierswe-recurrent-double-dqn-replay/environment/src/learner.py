"""Resume a recurrent replay learner from an explicit checkpoint."""
import numpy as np

from recurrent import backward, forward
from sensitivity import objective, prepare


def clipped(values, threshold):
    return np.where(values.real < -threshold, -threshold, np.where(values.real > threshold, threshold, values))


def targets_for(segment, online_values, target_values, config):
    returns = []
    for start in range(segment["burn_in"], segment["burn_in"] + segment["learn_length"]):
        total = 0.0
        discount = 1.0
        for position in range(start, min(start + config["n_step"], len(segment["rewards"]))):
            total += discount * clipped(segment["rewards"][position], config["reward_clip"])
            discount *= config["gamma"]
            if segment["terminated"][position] or segment["truncated"][position]:
                break
        if not (segment["terminated"][position] or segment["truncated"][position]):
            allowed = sorted(segment["legal_actions"][position])
            selected = allowed[int(np.argmax(online_values[position + 1, allowed].real))]
            total += discount * target_values[position + 1, selected].real
        returns.append(total)
    return np.array(returns)


def tensors(values):
    return {name: np.array(value, dtype=np.complex128 if np.iscomplexobj(value) else np.float64) for name, value in values.items()}


def serialize(values):
    return {name: value.tolist() for name, value in values.items()}


def run_case(snapshot, case, controls=None, trace=None):
    if controls is not None:
        snapshot, case = prepare(snapshot, case, controls)
    online = tensors(snapshot["online"])
    target = tensors(snapshot["target"])
    first_moment = tensors(snapshot["optimizer"]["m"])
    second_moment = tensors(snapshot["optimizer"]["v"])
    step = snapshot["optimizer"]["step"]
    priorities = dict(snapshot["priorities"])
    config = case["config"]
    aggregation = config["advantage_aggregation"]
    updates = []
    prefix = 0.0
    for batch in case["batches"]:
        baseline = objective(online, snapshot, aggregation) / len(case["batches"])
        normalizer = np.log(sum(value**config["alpha"] for value in priorities.values()))
        prefix += sum(np.log(priorities[name]) - normalizer for name in batch)
        raw_weights = np.array([priorities[name] ** (-config["alpha"] * config["beta"]) for name in batch])
        weights = raw_weights / raw_weights[np.argmax(raw_weights.real)].real
        gradients = {name: np.zeros_like(value) for name, value in online.items()}
        draws = []
        replacements = {}
        loss = 0.0
        for ordinal, sequence_id in enumerate(batch):
            segment = snapshot["segments"][sequence_id]
            online_values, cache = forward(online, segment["observations"], segment["online_hidden"], aggregation)
            target_values, _ = forward(target, segment["observations"], segment["target_hidden"], aggregation)
            returns = targets_for(segment, online_values, target_values, config)
            start = segment["burn_in"]
            stop = start + segment["learn_length"]
            predictions = online_values[np.arange(start, stop), segment["actions"][start:stop]]
            errors = returns - predictions
            absolute = np.sign(errors.real) * errors
            threshold = config["huber_delta"]
            huber = np.where(absolute.real <= threshold, 0.5 * errors**2, threshold * (absolute - 0.5 * threshold))
            loss += weights[ordinal] * huber.mean() / len(batch)
            derivatives = -clipped(errors, threshold) * weights[ordinal] / (len(batch) * len(errors))
            draw_gradients = backward(online, cache, start, stop, segment["actions"], derivatives, aggregation)
            for name in gradients:
                gradients[name] += draw_gradients[name]
            raw = config["priority_epsilon"] + config["priority_mix"] * absolute[np.argmax(absolute.real)] + (1 - config["priority_mix"]) * absolute.mean()
            if sequence_id not in replacements or raw.real > replacements[sequence_id].real:
                replacements[sequence_id] = raw.item()
            draws.append({
                "draw": ordinal, "sequence_id": sequence_id,
                "n_step_return": returns.tolist(), "td_error": errors.tolist(),
                "is_weight": weights[ordinal].item(),
                "new_priority": (raw**config["alpha"] if config["priority_power"] else raw).item(),
            })
        norm = np.sqrt(sum(np.sum(value * value) for value in gradients.values())).item()
        scale = min(1.0, config["grad_clip"] / np.real(norm)) if np.real(norm) else 1.0
        step += 1
        for name in online:
            gradient = gradients[name] * scale
            first_moment[name] = config["beta1"] * first_moment[name] + (1 - config["beta1"]) * gradient
            second_moment[name] = config["beta2"] * second_moment[name] + (1 - config["beta2"]) * gradient**2
            corrected_first = first_moment[name] / (1 - config["beta1"]**step)
            corrected_second = second_moment[name] / (1 - config["beta2"]**step)
            online[name] = (1 - config["lr"] * config["weight_decay"]) * online[name] - config["lr"] * corrected_first / (np.sqrt(corrected_second) + config["adam_epsilon"])
        if step % config["target_interval"] == 0:
            target = {name: (1 - config["tau"]) * target[name] + config["tau"] * online[name] for name in target}
        priorities.update({
            name: raw**config["alpha"] if config["priority_power"] else raw
            for name, raw in replacements.items()
        })
        if trace is not None:
            trace.append({"prefix": prefix, "baseline": baseline,
                          "cost": objective(online, snapshot, aggregation) / len(case["batches"])})
        updates.append({
            "step": step, "draws": draws, "loss": loss.item(), "gradient_norm": norm,
            "online": serialize(online), "target": serialize(target),
            "optimizer": {"step": step, "m": serialize(first_moment), "v": serialize(second_moment)},
            "priorities": dict(priorities),
        })
    return {"id": case["id"], "updates": updates}, objective(online, snapshot, aggregation)


def calibration_gradient(snapshot, case, controls):
    trace = []
    run_case(snapshot, case, controls, trace)
    gradient = np.zeros(len(controls))
    for index in range(len(controls)):
        perturbed = np.array(controls, dtype=np.complex128)
        perturbed[index] += 1e-24j
        shifted = []
        run_case(snapshot, case, perturbed, shifted)
        previous = 0.0
        for base, current in zip(trace, shifted):
            score = current["prefix"].imag / 1e-24
            gradient[index] += current["cost"].imag / 1e-24 + base["cost"] * score - base["baseline"] * (score - previous)
            previous = score
    return gradient


def resume(snapshot):
    cases = []
    order = snapshot["meta"]["control_order"]
    for case in snapshot["cases"]:
        trace = []
        result, value = run_case(snapshot, case, trace=trace)
        controls = np.zeros(len(order))
        gradient = calibration_gradient(snapshot, case, controls)
        curvature = {}
        for name, vector in snapshot["meta"]["curvature_directions"].items():
            shift = 2e-5 * np.asarray(vector)
            curvature[name] = ((calibration_gradient(snapshot, case, shift)
                                - calibration_gradient(snapshot, case, -shift)) / 4e-5).tolist()
        result["meta"] = {
            "validation_loss": float(value), "replay_loss": float(sum(stage["cost"] for stage in trace)),
            "hypergradient": dict(zip(order, gradient.tolist())), "curvature": curvature,
        }
        cases.append(result)
    return {"cases": cases}
