"""Recurrent Double-DQN forward pass and analytical reverse accumulation."""
import numpy as np


def forward(parameters, observations, initial_hidden, aggregation):
    hidden = np.asarray(initial_hidden)
    values = []
    caches = []
    for observation in observations:
        observation = np.asarray(observation)
        first_affine = observation @ parameters["W1"] + parameters["b1"]
        first = np.where(first_affine.real > 0, first_affine, 0.0)
        second_affine = first @ parameters["W2"] + parameters["b2"]
        second = second_affine
        previous = hidden
        hidden = np.tanh(second @ parameters["Wx"] + previous @ parameters["Wh"] + parameters["bh"])
        advantage = hidden @ parameters["Wa"] + parameters["ba"]
        value = (hidden @ parameters["Wv"] + parameters["bv"])[0]
        center = advantage.mean() if aggregation == "mean" else advantage[np.argmax(advantage.real)]
        values.append(value + advantage - center)
        caches.append((observation, first_affine, first, second_affine, second, previous, hidden, advantage))
    return np.array(values), caches


def backward(parameters, caches, start, stop, actions, prediction_derivatives, aggregation):
    gradient = {name: np.zeros_like(value) for name, value in parameters.items()}
    hidden_derivative = np.zeros_like(parameters["bh"])
    for position in range(stop - 1, start - 1, -1):
        observation, first_affine, first, second_affine, second, previous, hidden, advantage = caches[position]
        derivative = prediction_derivatives[position - start]
        advantage_derivative = np.zeros_like(advantage)
        advantage_derivative[actions[position]] += derivative
        if aggregation == "mean":
            advantage_derivative -= derivative / len(advantage)
        else:
            advantage_derivative[np.argmax(advantage.real)] -= derivative
        gradient["Wv"] += hidden[:, None] * derivative
        gradient["bv"] += derivative
        gradient["Wa"] += np.outer(hidden, advantage_derivative)
        gradient["ba"] += advantage_derivative
        hidden_derivative += parameters["Wv"][:, 0] * derivative + parameters["Wa"] @ advantage_derivative
        recurrent_derivative = hidden_derivative * (1.0 - hidden * hidden)
        gradient["Wx"] += np.outer(second, recurrent_derivative)
        gradient["Wh"] += np.outer(previous, recurrent_derivative)
        gradient["bh"] += recurrent_derivative
        second_derivative = parameters["Wx"] @ recurrent_derivative
        gradient["W2"] += np.outer(first, second_derivative)
        gradient["b2"] += second_derivative
        first_derivative = (parameters["W2"] @ second_derivative) * (first_affine.real > 0)
        gradient["W1"] += np.outer(observation, first_derivative)
        gradient["b1"] += first_derivative
        hidden_derivative = parameters["Wh"] @ recurrent_derivative
    return gradient
