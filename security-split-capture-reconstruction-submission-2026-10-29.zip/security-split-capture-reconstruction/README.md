# Split-capture TLS exfiltration reconstruction

This task presents a fixed synthetic incident-response evidence set containing inside and
edge packet captures, NAT mappings, sensor-clock calibration, asset records, TLS session
secrets, and a documented application protocol. Different packets are missing from each
capture, so the target stream can only be recovered by correlating and merging both network
vantage points.

The intended analysis normalizes sensor time, maps the pre-NAT and post-NAT tuples, performs
sequence-aware TCP reassembly, decrypts the matching TLS 1.3 session, and reconstructs a
restricted-export object from multiplexed HTTP/2 NFX2 chunks.

The Python image includes common packet-analysis utilities and pinned verifier dependencies.
Only evidence under `/app/evidence` is present during the agent run.

Verification checks two pre-existing artifacts without running agent code: the recovered
object must match a protected byte sequence exactly, and the incident report must match the
documented schema and independently generated forensic facts. Artifact symlinks are rejected.

Validated locally on 2026-10-29: `frontierswe-check.py` reports PASS with no
FAIL and no WARN lines, `-a oracle` scores `Mean: 1.000`, and `-a nop` scores
`Mean: 0.000` (Harbor 0.20.0). The checker's PASS line and its content
fingerprint are recorded in `../evaluation-sample-kit/VALIDATION.md`; the
fingerprint is deliberately not repeated here, since it covers this file too.
