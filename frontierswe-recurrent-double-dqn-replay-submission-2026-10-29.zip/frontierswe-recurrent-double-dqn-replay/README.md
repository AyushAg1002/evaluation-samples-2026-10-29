# Recurrent Double-DQN replay continuation

A long-horizon reinforcement-learning systems task. The agent repairs a paused
recurrent Double-DQN learner, including replay prioritization, AdamW state
resumption, and a nine-coordinate higher-order calibration calculation.

The task folder is self-contained:

- `instruction.md` is the agent-facing brief.
- `environment/` contains only public inputs and the intentionally flawed starter.
- `tests/` contains a protected static-artifact verifier.
- `solution/solve.sh` restores the validated reference implementation.

Validated locally on 2026-10-29: `frontierswe-check.py` reports PASS with no
FAIL and no WARN lines, `-a oracle` scores `Mean: 1.000`, and `-a nop` scores
`Mean: 0.000` (Harbor 0.20.0). The checker's PASS line and its content
fingerprint are recorded in `../evaluation-sample-kit/VALIDATION.md`; the
fingerprint is deliberately not repeated here, since it covers this file too.
