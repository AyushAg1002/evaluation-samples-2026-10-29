import hashlib
import json
import os
import re
import stat
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile


_CONTAINER_APP_ROOT = Path("/app")
# Inside the task container /app is authoritative, so the environment cannot
# redirect the verifier; the override exists only for running these tests
# outside a container.
APP_ROOT = (
    _CONTAINER_APP_ROOT
    if _CONTAINER_APP_ROOT.is_dir()
    else Path(os.environ.get("TASK_TEST_APP_ROOT", "/app"))
)
ARCHIVE_PATH = APP_ROOT / "recovered" / "exfiltrated.bin"
REPORT_PATH = APP_ROOT / "incident_report.json"
FIXTURE_ROOT = Path(__file__).resolve().parent / "fixtures"
EXPECTED = json.loads((FIXTURE_ROOT / "expected.json").read_text())


def assert_regular_artifact(path):
    metadata = path.lstat()
    assert stat.S_ISREG(metadata.st_mode), f"{path} must be a regular file"
    assert not path.is_symlink(), f"{path} must not be a symlink"
    # A hard link has no link target, so resolve() alone would report an
    # in-/app path for bytes that live outside it.
    assert metadata.st_nlink == 1, f"{path} must not be a hard link"
    resolved = path.resolve(strict=True)
    resolved.relative_to(APP_ROOT.resolve(strict=True))


def load_report():
    return json.loads(REPORT_PATH.read_text())


def parse_utc(value):
    assert isinstance(value, str)
    assert re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{6}Z", value)
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def test_required_artifacts_are_regular_files():
    """Both declared outputs exist as non-symlink regular files beneath /app."""
    assert_regular_artifact(ARCHIVE_PATH)
    assert_regular_artifact(REPORT_PATH)


def test_recovered_archive_matches_the_exfiltrated_object():
    """The recovered object is the exact protected byte sequence sent by the restricted export."""
    actual = ARCHIVE_PATH.read_bytes()
    expected_bytes = (FIXTURE_ROOT / "expected_recovered.zip").read_bytes()
    assert actual == expected_bytes
    assert len(actual) == EXPECTED["archive_size"]
    assert hashlib.sha256(actual).hexdigest() == EXPECTED["archive_sha256"]


def test_incident_report_has_the_exact_schema():
    """incident_report.json uses only the documented objects, fields, and value types."""
    report = load_report()
    assert set(report) == {
        "case_id",
        "victim",
        "nat",
        "destination",
        "tls_client_random",
        "object",
        "reassembly",
        "transfer",
    }
    assert set(report["victim"]) == {"ip", "mac", "hostname"}
    assert set(report["nat"]) == {"public_ip", "public_port"}
    assert set(report["destination"]) == {"ip", "port", "sni"}
    assert set(report["object"]) == {"name", "size_bytes", "sha256", "chunk_count"}
    assert set(report["reassembly"]) == {
        "client_stream_bytes",
        "shared_bytes",
        "inside_only_bytes",
        "edge_only_bytes",
    }
    assert set(report["transfer"]) == {"first_chunk_utc", "last_chunk_utc", "chunk_utc"}
    assert isinstance(report["case_id"], str)
    assert all(isinstance(report["victim"][field], str) for field in report["victim"])
    assert isinstance(report["nat"]["public_ip"], str)
    assert isinstance(report["nat"]["public_port"], int) and not isinstance(report["nat"]["public_port"], bool)
    assert isinstance(report["destination"]["ip"], str)
    assert isinstance(report["destination"]["port"], int) and not isinstance(report["destination"]["port"], bool)
    assert isinstance(report["destination"]["sni"], str)
    assert isinstance(report["tls_client_random"], str)
    assert isinstance(report["object"]["name"], str)
    assert isinstance(report["object"]["size_bytes"], int) and not isinstance(report["object"]["size_bytes"], bool)
    assert isinstance(report["object"]["sha256"], str)
    assert isinstance(report["object"]["chunk_count"], int) and not isinstance(report["object"]["chunk_count"], bool)
    for field in report["reassembly"]:
        value = report["reassembly"][field]
        assert isinstance(value, int) and not isinstance(value, bool)
    assert isinstance(report["transfer"]["first_chunk_utc"], str)
    assert isinstance(report["transfer"]["last_chunk_utc"], str)
    assert isinstance(report["transfer"]["chunk_utc"], list)
    assert all(isinstance(value, str) for value in report["transfer"]["chunk_utc"])


def test_report_identifies_the_correct_network_session():
    """The report identifies the victim, NAT mapping, destination, and TLS session exactly."""
    report = load_report()
    expected = EXPECTED["report"]
    assert report["case_id"] == expected["case_id"]
    assert report["victim"] == expected["victim"]
    assert report["nat"] == expected["nat"]
    assert report["destination"] == expected["destination"]
    assert report["tls_client_random"] == expected["tls_client_random"]


def test_report_describes_the_recovered_object_exactly():
    """Object name, size, digest, and chunk count match the reconstructed restricted export."""
    report = load_report()
    assert report["object"] == EXPECTED["report"]["object"]
    actual = ARCHIVE_PATH.read_bytes()
    assert report["object"]["size_bytes"] == len(actual)
    assert report["object"]["sha256"] == hashlib.sha256(actual).hexdigest()
    with ZipFile(ARCHIVE_PATH) as archive:
        assert set(archive.namelist()) == {
            "board/agenda.txt",
            "board/covenants.csv",
            "board/forecast_model.bin",
            "board/scenario_notes.md",
        }
        assert archive.testzip() is None


def test_reassembly_accounts_for_both_vantage_points():
    """The per-sensor byte accounting matches, and is internally consistent.

    A single merged capture cannot produce this: it requires knowing which
    sensor observed each byte of the reassembled client stream.
    """
    report = load_report()
    actual = report["reassembly"]
    assert actual == EXPECTED["report"]["reassembly"]
    assert (
        actual["shared_bytes"] + actual["inside_only_bytes"] + actual["edge_only_bytes"]
        == actual["client_stream_bytes"]
    ), "the three byte classes must partition the client stream"
    assert actual["inside_only_bytes"] > 0 and actual["edge_only_bytes"] > 0, (
        "neither capture is complete, so both must contribute bytes the other lacks"
    )


def test_every_chunk_observation_time_matches():
    """All chunk times match, not only the first and last.

    This is what makes the protocol's "use the earlier corrected observation
    when both sensors captured the byte" rule load-bearing: taking the later
    observation instead moves eleven of these chunks by up to 45 ms.
    """
    report = load_report()
    expected = EXPECTED["report"]["transfer"]["chunk_utc"]
    actual = report["transfer"]["chunk_utc"]
    assert len(actual) == len(expected), f"expected {len(expected)} chunk times"
    assert len(actual) == report["object"]["chunk_count"], (
        "one observation time per manifest chunk"
    )
    parsed = [parse_utc(value) for value in actual]
    assert parsed == sorted(parsed), "chunk times must be in ascending order"
    for index, (got, want) in enumerate(zip(parsed, expected)):
        delta = abs((got - parse_utc(want)).total_seconds())
        assert delta <= 0.010, f"chunk {index} is {delta * 1000:.3f} ms off"


def test_transfer_times_follow_the_documented_clock_rule():
    """First and last chunk observations are within 10 ms of the independently generated truth."""
    report = load_report()
    expected = EXPECTED["report"]["transfer"]
    actual_start = parse_utc(report["transfer"]["first_chunk_utc"])
    actual_end = parse_utc(report["transfer"]["last_chunk_utc"])
    expected_start = parse_utc(expected["first_chunk_utc"])
    expected_end = parse_utc(expected["last_chunk_utc"])
    assert actual_start <= actual_end
    assert abs((actual_start - expected_start).total_seconds()) <= 0.010
    assert abs((actual_end - expected_end).total_seconds()) <= 0.010
