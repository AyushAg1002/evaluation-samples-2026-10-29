# Submission brief

**Category:** Model Training and ML Infrastructure — Reinforcement Learning Systems

This is a self-contained long-horizon repair task. The agent must recover a
recurrent prioritized-replay learner's ordinary updates and the specified
higher-order replay-calibration derivatives from an explicit synthetic
checkpoint. The protected verifier checks every saved update, state tensor,
priority table, hypergradient, and curvature product without executing
agent-controlled code.

Run the submission gates from this directory:

```sh
python3 /path/to/frontierswe-check.py .
harbor run -p . -a oracle
harbor run -p . -a nop
```

All three gates are verified for the current contents (2026-10-29, Harbor
0.20.0): the checker reports PASS with no FAIL and no WARN lines, Oracle scores
`Mean: 1.000`, and NOP scores `Mean: 0.000`. The checker's PASS line, including
its content fingerprint, is recorded in
`../evaluation-sample-kit/VALIDATION.md`.
