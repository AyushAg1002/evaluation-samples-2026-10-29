#!/usr/bin/env python3

import csv
import hashlib
import ipaddress
import json
import os
import random
import ssl
import struct
import tempfile
import zlib
from datetime import datetime, timedelta, timezone
from io import BytesIO
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID


TASK_ROOT = Path(__file__).resolve().parents[1]
EVIDENCE_DIR = TASK_ROOT / "environment" / "data" / "evidence"
FIXTURE_DIR = TASK_ROOT / "tests" / "fixtures"

CASE_ID = "IR-2026-0417"
BASE_UTC = datetime(2026, 4, 17, 9, 42, 0, tzinfo=timezone.utc).timestamp()
TARGET_OBJECT_ID = bytes.fromhex("6b6e6f776e2d657866696c2d30303031")

INTERNAL_CLOCK_OFFSET = 0.482
INTERNAL_CLOCK_DRIFT = 18e-6
EDGE_CLOCK_OFFSET = -0.237
EDGE_CLOCK_DRIFT = -11e-6

POLICY_CODES = {"public": 1, "internal": 2, "restricted": 3}
OPERATION_CODES = {"sync": 1, "export": 2}


def sensor_time(sensor, true_time):
    elapsed = true_time - BASE_UTC
    if sensor == "inside":
        return true_time + INTERNAL_CLOCK_OFFSET + INTERNAL_CLOCK_DRIFT * elapsed
    return true_time + EDGE_CLOCK_OFFSET + EDGE_CLOCK_DRIFT * elapsed


def iso8601(timestamp):
    value = datetime.fromtimestamp(timestamp, timezone.utc)
    return value.isoformat(timespec="microseconds").replace("+00:00", "Z")


def internet_checksum(data):
    if len(data) % 2:
        data += b"\x00"
    total = sum(struct.unpack(f"!{len(data) // 2}H", data))
    while total >> 16:
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


def mac_bytes(value):
    return bytes.fromhex(value.replace(":", ""))


def build_tcp_packet(src_mac, dst_mac, src_ip, dst_ip, src_port, dst_port, seq, ack, flags, payload, packet_id):
    source_ip = ipaddress.IPv4Address(src_ip).packed
    destination_ip = ipaddress.IPv4Address(dst_ip).packed

    tcp_header = struct.pack(
        "!HHIIBBHHH",
        src_port,
        dst_port,
        seq,
        ack,
        5 << 4,
        flags,
        65535,
        0,
        0,
    )
    pseudo_header = source_ip + destination_ip + struct.pack("!BBH", 0, 6, len(tcp_header) + len(payload))
    tcp_checksum = internet_checksum(pseudo_header + tcp_header + payload)
    tcp_header = struct.pack(
        "!HHIIBBHHH",
        src_port,
        dst_port,
        seq,
        ack,
        5 << 4,
        flags,
        65535,
        tcp_checksum,
        0,
    )

    total_length = 20 + len(tcp_header) + len(payload)
    ip_header = struct.pack(
        "!BBHHHBBH4s4s",
        0x45,
        0,
        total_length,
        packet_id & 0xFFFF,
        0x4000,
        64,
        6,
        0,
        source_ip,
        destination_ip,
    )
    ip_checksum = internet_checksum(ip_header)
    ip_header = struct.pack(
        "!BBHHHBBH4s4s",
        0x45,
        0,
        total_length,
        packet_id & 0xFFFF,
        0x4000,
        64,
        6,
        ip_checksum,
        source_ip,
        destination_ip,
    )
    ethernet = mac_bytes(dst_mac) + mac_bytes(src_mac) + struct.pack("!H", 0x0800)
    return ethernet + ip_header + tcp_header + payload


def build_udp_packet(src_mac, dst_mac, src_ip, dst_ip, src_port, dst_port, payload, packet_id):
    source_ip = ipaddress.IPv4Address(src_ip).packed
    destination_ip = ipaddress.IPv4Address(dst_ip).packed
    udp_header = struct.pack("!HHHH", src_port, dst_port, 8 + len(payload), 0)
    total_length = 20 + len(udp_header) + len(payload)
    ip_header = struct.pack(
        "!BBHHHBBH4s4s",
        0x45,
        0,
        total_length,
        packet_id & 0xFFFF,
        0,
        61,
        17,
        0,
        source_ip,
        destination_ip,
    )
    ip_checksum = internet_checksum(ip_header)
    ip_header = struct.pack(
        "!BBHHHBBH4s4s",
        0x45,
        0,
        total_length,
        packet_id & 0xFFFF,
        0,
        61,
        17,
        ip_checksum,
        source_ip,
        destination_ip,
    )
    ethernet = mac_bytes(dst_mac) + mac_bytes(src_mac) + struct.pack("!H", 0x0800)
    return ethernet + ip_header + udp_header + payload


def write_pcap(path, packets):
    path.parent.mkdir(parents=True, exist_ok=True)
    output = bytearray(struct.pack("<IHHIIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))
    for timestamp, packet in sorted(packets, key=lambda item: item[0]):
        seconds = int(timestamp)
        microseconds = int(round((timestamp - seconds) * 1_000_000))
        if microseconds == 1_000_000:
            seconds += 1
            microseconds = 0
        output.extend(struct.pack("<IIII", seconds, microseconds, len(packet), len(packet)))
        output.extend(packet)
    path.write_bytes(output)


def deterministic_zip():
    buffer = BytesIO()
    files = {
        "board/agenda.txt": (
            "Q3 treasury review\n"
            "1. Liquidity runway\n"
            "2. Acquisition sensitivity\n"
            "3. Restricted covenant amendments\n"
        ).encode(),
        "board/covenants.csv": (
            "facility,limit_usd,current_usd,headroom_usd\n"
            "RCF-A,45000000,31750000,13250000\n"
            "TERM-B,120000000,118200000,1800000\n"
            "BRIDGE-C,25000000,0,25000000\n"
        ).encode(),
        "board/scenario_notes.md": (
            "# Confidential scenarios\n\n"
            "The downside case assumes a 14% revenue contraction, a 230 bps margin decline, "
            "and covenant remediation before 2026-09-30.\n"
        ).encode(),
        "board/forecast_model.bin": random_payload("restricted-forecast-model", 32768),
    }
    with ZipFile(buffer, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in files.items():
            info = ZipInfo(name, date_time=(2026, 4, 16, 12, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    return buffer.getvalue()


def random_payload(label, size):
    output = bytearray()
    counter = 0
    while len(output) < size:
        output.extend(hashlib.sha256(f"{label}:{counter}".encode()).digest())
        counter += 1
    return bytes(output[:size])


def h2_frame(frame_type, flags, stream_id, payload):
    length = len(payload)
    return length.to_bytes(3, "big") + bytes([frame_type, flags]) + (stream_id & 0x7FFFFFFF).to_bytes(4, "big") + payload


def hpack_request_headers(authority):
    path = b"/v2/object-transfer"
    authority_bytes = authority.encode()
    return b"\x83\x87\x04" + bytes([len(path)]) + path + b"\x01" + bytes([len(authority_bytes)]) + authority_bytes


def manifest_message(object_spec):
    name = object_spec["name"].encode()
    payload = object_spec["payload"]
    digest = hashlib.sha256(payload).digest()
    header = struct.pack(
        "!4sB16sBBIHH32s",
        b"NFX2",
        1,
        object_spec["object_id"],
        POLICY_CODES[object_spec["policy"]],
        OPERATION_CODES[object_spec["operation"]],
        len(payload),
        object_spec["chunk_count"],
        len(name),
        digest,
    )
    return header + name


def chunk_message(object_id, offset, chunk):
    return struct.pack("!4sB16sIHI", b"NFX2", 2, object_id, offset, len(chunk), zlib.crc32(chunk)) + chunk


def build_http2_writes(authority, objects, shuffle_seed):
    writes = [
        {
            "payload": b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n" + h2_frame(4, 0, 0, b""),
            "kind": "control",
        }
    ]
    for object_spec in objects:
        writes.append(
            {
                "payload": h2_frame(1, 4, object_spec["stream_id"], hpack_request_headers(authority)),
                "kind": "headers",
            }
        )
        writes.append(
            {
                "payload": h2_frame(0, 0, object_spec["stream_id"], manifest_message(object_spec)),
                "kind": "manifest",
                "object_id": object_spec["object_id"].hex(),
            }
        )

    scheduled_chunks = []
    for object_spec in objects:
        payload = object_spec["payload"]
        chunk_size = object_spec["chunk_size"]
        chunks = []
        for offset in range(0, len(payload), chunk_size):
            chunks.append((offset, payload[offset : offset + chunk_size]))
        object_spec["chunk_count"] = len(chunks)
        rng = random.Random(shuffle_seed + object_spec["stream_id"])
        rng.shuffle(chunks)
        for offset, chunk in chunks:
            scheduled_chunks.append(
                {
                    "stream_id": object_spec["stream_id"],
                    "object_id": object_spec["object_id"].hex(),
                    "is_target": object_spec["object_id"] == TARGET_OBJECT_ID,
                    "offset": offset,
                    "payload": h2_frame(
                        0,
                        0,
                        object_spec["stream_id"],
                        chunk_message(object_spec["object_id"], offset, chunk),
                    ),
                }
            )
    random.Random(shuffle_seed).shuffle(scheduled_chunks)
    for item in scheduled_chunks:
        item["kind"] = "chunk"
        writes.append(item)
    return writes


def create_certificate(directory):
    private_key = ec.derive_private_key(
        0x43BFA9C2E793A49538A15A9E57805E7441EC47E17A9C12FA7AD89F1205A31D7,
        ec.SECP256R1(),
    )
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Dynamo Evidence Lab")])
    certificate = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(private_key.public_key())
        .serial_number(0x20260417)
        .not_valid_before(datetime(2026, 1, 1, tzinfo=timezone.utc))
        .not_valid_after(datetime(2027, 1, 1, tzinfo=timezone.utc))
        .add_extension(
            x509.SubjectAlternativeName(
                [
                    x509.DNSName("sync-archive.corp-example.net"),
                    x509.DNSName("updates.corp-example.net"),
                    x509.DNSName("telemetry.corp-example.net"),
                ]
            ),
            critical=False,
        )
        .sign(private_key, hashes.SHA256())
    )
    cert_path = directory / "server-cert.pem"
    key_path = directory / "server-key.pem"
    cert_path.write_bytes(certificate.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(
        private_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        )
    )
    return cert_path, key_path


def drain_bio(output_bio):
    chunks = []
    while output_bio.pending:
        chunks.append(output_bio.read())
    return b"".join(chunks)


def parse_client_random(client_stream):
    offset = 0
    while offset + 5 <= len(client_stream):
        content_type = client_stream[offset]
        length = int.from_bytes(client_stream[offset + 3 : offset + 5], "big")
        record = client_stream[offset + 5 : offset + 5 + length]
        if content_type == 22 and len(record) >= 38 and record[0] == 1:
            return record[6:38].hex()
        offset += 5 + length
    raise RuntimeError("ClientHello was not found")


def create_tls_events(cert_path, key_path, sni, writes, keylog_path):
    server_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    server_context.minimum_version = ssl.TLSVersion.TLSv1_3
    server_context.maximum_version = ssl.TLSVersion.TLSv1_3
    server_context.load_cert_chain(certfile=cert_path, keyfile=key_path)
    server_context.set_alpn_protocols(["h2"])

    client_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    client_context.minimum_version = ssl.TLSVersion.TLSv1_3
    client_context.maximum_version = ssl.TLSVersion.TLSv1_3
    client_context.check_hostname = False
    client_context.verify_mode = ssl.CERT_NONE
    client_context.set_alpn_protocols(["h2"])
    client_context.keylog_filename = str(keylog_path)

    client_in = ssl.MemoryBIO()
    client_out = ssl.MemoryBIO()
    server_in = ssl.MemoryBIO()
    server_out = ssl.MemoryBIO()
    client = client_context.wrap_bio(client_in, client_out, server_side=False, server_hostname=sni)
    server = server_context.wrap_bio(server_in, server_out, server_side=True)

    events = []
    client_done = False
    server_done = False
    for _ in range(100):
        progressed = False
        if not client_done:
            try:
                client.do_handshake()
                client_done = True
            except ssl.SSLWantReadError:
                pass
        client_bytes = drain_bio(client_out)
        if client_bytes:
            events.append({"direction": "c2s", "payload": client_bytes, "kind": "handshake"})
            server_in.write(client_bytes)
            progressed = True

        if not server_done:
            try:
                server.do_handshake()
                server_done = True
            except ssl.SSLWantReadError:
                pass
        server_bytes = drain_bio(server_out)
        if server_bytes:
            events.append({"direction": "s2c", "payload": server_bytes, "kind": "handshake"})
            client_in.write(server_bytes)
            progressed = True

        if client_done and server_done and not progressed:
            break
    if not client_done or not server_done:
        raise RuntimeError("TLS handshake did not complete")

    for write in writes:
        client.write(write["payload"])
        encrypted = drain_bio(client_out)
        event = dict(write)
        event.update({"direction": "c2s", "payload": encrypted})
        events.append(event)
        server_in.write(encrypted)
        while True:
            try:
                consumed = server.read(65535)
                if not consumed:
                    break
            except ssl.SSLWantReadError:
                break

        server_bytes = drain_bio(server_out)
        if server_bytes:
            events.append({"direction": "s2c", "payload": server_bytes, "kind": "server-control"})
            client_in.write(server_bytes)

    client_stream = b"".join(event["payload"] for event in events if event["direction"] == "c2s")
    return events, parse_client_random(client_stream), client.cipher()[0]


def packetize_flow(flow, events, flow_index):
    inside_packets = []
    edge_packets = []
    internal_client_seq = 1_000_000 + flow_index * 250_000
    server_seq = 7_000_000 + flow_index * 250_000
    client_seq = internal_client_seq
    current_server_seq = server_seq
    packet_id = 1000 + flow_index * 1000
    true_time = flow["start_time"]
    target_chunk_times = []
    application_packet_index = 0

    inside_client_mac = flow["client_mac"]
    inside_gateway_mac = "02:00:00:00:42:01"
    edge_firewall_mac = "02:00:00:00:51:01"
    edge_router_mac = "02:00:00:00:51:fe"

    def append_packet(direction, payload, seq, ack, flags, timestamp, include_inside=True, include_edge=True):
        nonlocal packet_id
        if direction == "c2s":
            inside_args = (
                inside_client_mac,
                inside_gateway_mac,
                flow["internal_ip"],
                flow["destination_ip"],
                flow["internal_port"],
                443,
            )
            edge_args = (
                edge_firewall_mac,
                edge_router_mac,
                flow["public_ip"],
                flow["destination_ip"],
                flow["public_port"],
                443,
            )
        else:
            inside_args = (
                inside_gateway_mac,
                inside_client_mac,
                flow["destination_ip"],
                flow["internal_ip"],
                443,
                flow["internal_port"],
            )
            edge_args = (
                edge_router_mac,
                edge_firewall_mac,
                flow["destination_ip"],
                flow["public_ip"],
                443,
                flow["public_port"],
            )
        if include_inside:
            packet = build_tcp_packet(*inside_args, seq, ack, flags, payload, packet_id)
            inside_packets.append((sensor_time("inside", timestamp), packet))
        if include_edge:
            packet = build_tcp_packet(*edge_args, seq, ack, flags, payload, packet_id)
            edge_packets.append((sensor_time("edge", timestamp), packet))
        packet_id += 1

    append_packet("c2s", b"", client_seq, 0, 0x02, true_time)
    true_time += 0.004
    append_packet("s2c", b"", current_server_seq, client_seq + 1, 0x12, true_time)
    true_time += 0.004
    client_seq += 1
    current_server_seq += 1
    append_packet("c2s", b"", client_seq, current_server_seq, 0x10, true_time)
    true_time += 0.010

    segment_pattern = [431, 677, 509, 823, 347, 701]
    for event_index, event in enumerate(events):
        direction = event["direction"]
        payload = event["payload"]
        if event.get("is_target"):
            target_chunk_times.append(true_time)
        cursor = 0
        segment_index = 0
        while cursor < len(payload):
            segment_size = segment_pattern[(event_index + segment_index) % len(segment_pattern)]
            segment = payload[cursor : cursor + segment_size]
            include_inside = True
            include_edge = True
            is_application = direction == "c2s" and event["kind"] not in {"handshake"}
            if flow["is_target_flow"] and is_application:
                include_inside = application_packet_index % 7 != 2
                include_edge = application_packet_index % 7 != 5
                application_packet_index += 1

            if direction == "c2s":
                segment_seq = client_seq
                append_packet(
                    direction,
                    segment,
                    segment_seq,
                    current_server_seq,
                    0x18,
                    true_time,
                    include_inside,
                    include_edge,
                )
                client_seq += len(segment)
            else:
                segment_seq = current_server_seq
                append_packet(
                    direction,
                    segment,
                    segment_seq,
                    client_seq,
                    0x18,
                    true_time,
                    include_inside,
                    include_edge,
                )
                current_server_seq += len(segment)

            if is_application and application_packet_index % 9 == 0:
                append_packet(
                    direction,
                    segment,
                    segment_seq,
                    current_server_seq if direction == "c2s" else client_seq,
                    0x18,
                    true_time + 0.045,
                    include_inside,
                    include_edge,
                )
            cursor += len(segment)
            segment_index += 1
            true_time += 0.0015
        true_time += 0.018

    append_packet("c2s", b"", client_seq, current_server_seq, 0x11, true_time)
    true_time += 0.004
    append_packet("s2c", b"", current_server_seq, client_seq + 1, 0x11, true_time)
    return inside_packets, edge_packets, target_chunk_times, true_time


def add_background_traffic(inside_packets, edge_packets):
    for index in range(36):
        true_time = BASE_UTC + 1.2 + index * 0.83
        query = (
            b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00"
            + bytes([7])
            + b"service"
            + bytes([4])
            + b"corp"
            + bytes([7])
            + b"example"
            + b"\x00\x00\x01\x00\x01"
        )
        inside = build_udp_packet(
            "02:00:00:00:42:30",
            "02:00:00:00:42:01",
            f"10.42.7.{40 + index % 8}",
            "10.42.0.53",
            53000 + index,
            53,
            query,
            50000 + index,
        )
        edge = build_udp_packet(
            "02:00:00:00:51:01",
            "02:00:00:00:51:fe",
            "198.51.100.24",
            "192.0.2.53",
            46000 + index,
            53,
            query,
            51000 + index,
        )
        inside_packets.append((sensor_time("inside", true_time), inside))
        edge_packets.append((sensor_time("edge", true_time + 0.006), edge))


def prepare_object(name, object_id, stream_id, policy, operation, payload, chunk_size):
    return {
        "name": name,
        "object_id": object_id,
        "stream_id": stream_id,
        "policy": policy,
        "operation": operation,
        "payload": payload,
        "chunk_size": chunk_size,
        "chunk_count": (len(payload) + chunk_size - 1) // chunk_size,
    }


def main():
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    FIXTURE_DIR.mkdir(parents=True, exist_ok=True)

    target_payload = deterministic_zip()
    flows = [
        {
            "flow_id": "F-1042",
            "is_target_flow": False,
            "internal_ip": "10.42.7.31",
            "internal_port": 51880,
            "client_mac": "02:00:00:42:07:31",
            "hostname": "eng-ws-04",
            "public_ip": "198.51.100.24",
            "public_port": 41998,
            "destination_ip": "203.0.113.77",
            "sni": "sync-archive.corp-example.net",
            "start_time": BASE_UTC + 4.0,
            "objects": [
                prepare_object(
                    "build_metrics.bin",
                    bytes.fromhex("62656e69676e2d6d6574726963733031"),
                    1,
                    "internal",
                    "sync",
                    random_payload("metrics", 4096),
                    601,
                )
            ],
        },
        {
            "flow_id": "F-1047",
            "is_target_flow": True,
            "internal_ip": "10.42.7.23",
            "internal_port": 51514,
            "client_mac": "02:00:00:42:07:23",
            "hostname": "acct-ws-17",
            "public_ip": "198.51.100.24",
            "public_port": 42001,
            "destination_ip": "203.0.113.77",
            "sni": "sync-archive.corp-example.net",
            "start_time": BASE_UTC + 12.0,
            "objects": [
                prepare_object(
                    "desktop-index.bin",
                    bytes.fromhex("62656e69676e2d696e6465782d303030"),
                    1,
                    "internal",
                    "sync",
                    random_payload("desktop-index", 3072),
                    487,
                ),
                prepare_object(
                    "board_packet_q3.zip",
                    TARGET_OBJECT_ID,
                    5,
                    "restricted",
                    "export",
                    target_payload,
                    733,
                ),
            ],
        },
        {
            "flow_id": "F-1051",
            "is_target_flow": False,
            "internal_ip": "10.42.7.23",
            "internal_port": 51532,
            "client_mac": "02:00:00:42:07:23",
            "hostname": "acct-ws-17",
            "public_ip": "198.51.100.24",
            "public_port": 42006,
            "destination_ip": "203.0.113.88",
            "sni": "updates.corp-example.net",
            "start_time": BASE_UTC + 24.0,
            "objects": [
                prepare_object(
                    "agent-status.bin",
                    bytes.fromhex("62656e69676e2d7374617475732d3031"),
                    1,
                    "public",
                    "sync",
                    random_payload("status", 3584),
                    557,
                )
            ],
        },
    ]

    inside_packets = []
    edge_packets = []
    keylog_lines = ["# TLS secrets for the three retained enterprise sessions"]
    expected_target = None

    with tempfile.TemporaryDirectory(prefix="dynamo-network-evidence-") as temporary:
        temporary_path = Path(temporary)
        cert_path, key_path = create_certificate(temporary_path)
        for flow_index, flow in enumerate(flows):
            writes = build_http2_writes(flow["sni"], flow["objects"], 9000 + flow_index * 100)
            session_keylog = temporary_path / f"session-{flow_index}.keys"
            events, client_random, cipher = create_tls_events(
                cert_path,
                key_path,
                flow["sni"],
                writes,
                session_keylog,
            )
            for line in session_keylog.read_text().splitlines():
                if line and not line.startswith("#"):
                    keylog_lines.append(line)
            flow["client_random"] = client_random
            flow["cipher"] = cipher
            flow_inside, flow_edge, target_times, end_time = packetize_flow(flow, events, flow_index)
            inside_packets.extend(flow_inside)
            edge_packets.extend(flow_edge)
            flow["end_time"] = end_time
            if flow["is_target_flow"]:
                target_object = next(item for item in flow["objects"] if item["object_id"] == TARGET_OBJECT_ID)
                expected_target = {
                    "flow": flow,
                    "object": target_object,
                    "chunk_times": target_times,
                }

    add_background_traffic(inside_packets, edge_packets)
    write_pcap(EVIDENCE_DIR / "inside_sensor.pcap", inside_packets)
    write_pcap(EVIDENCE_DIR / "edge_sensor.pcap", edge_packets)
    (EVIDENCE_DIR / "tls_session_keys.log").write_text("\n".join(keylog_lines) + "\n")

    with (EVIDENCE_DIR / "firewall_nat.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "flow_id",
                "created_utc",
                "closed_utc",
                "internal_ip",
                "internal_port",
                "public_ip",
                "public_port",
                "destination_ip",
                "destination_port",
            ],
        )
        writer.writeheader()
        for flow in flows:
            writer.writerow(
                {
                    "flow_id": flow["flow_id"],
                    "created_utc": iso8601(flow["start_time"] - 0.5),
                    "closed_utc": iso8601(flow["end_time"] + 0.5),
                    "internal_ip": flow["internal_ip"],
                    "internal_port": flow["internal_port"],
                    "public_ip": flow["public_ip"],
                    "public_port": flow["public_port"],
                    "destination_ip": flow["destination_ip"],
                    "destination_port": 443,
                }
            )

    with (EVIDENCE_DIR / "asset_inventory.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["ip", "mac", "hostname", "owner_team"])
        writer.writeheader()
        seen = set()
        for flow in flows:
            key = (flow["internal_ip"], flow["client_mac"])
            if key in seen:
                continue
            seen.add(key)
            writer.writerow(
                {
                    "ip": flow["internal_ip"],
                    "mac": flow["client_mac"],
                    "hostname": flow["hostname"],
                    "owner_team": "Finance" if flow["internal_ip"] == "10.42.7.23" else "Engineering",
                }
            )

    with (EVIDENCE_DIR / "sensor_clock_calibration.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["sensor", "trusted_utc_epoch_s", "sensor_epoch_s"])
        writer.writeheader()
        for sensor in ("inside", "edge"):
            for delta in (0.0, 30.0, 60.0):
                trusted = BASE_UTC + delta
                writer.writerow(
                    {
                        "sensor": sensor,
                        "trusted_utc_epoch_s": f"{trusted:.6f}",
                        "sensor_epoch_s": f"{sensor_time(sensor, trusted):.6f}",
                    }
                )

    flow = expected_target["flow"]
    target_object = expected_target["object"]
    target_times = expected_target["chunk_times"]
    report = {
        "case_id": CASE_ID,
        "victim": {
            "ip": flow["internal_ip"],
            "mac": flow["client_mac"],
            "hostname": flow["hostname"],
        },
        "nat": {
            "public_ip": flow["public_ip"],
            "public_port": flow["public_port"],
        },
        "destination": {
            "ip": flow["destination_ip"],
            "port": 443,
            "sni": flow["sni"],
        },
        "tls_client_random": flow["client_random"],
        "object": {
            "name": target_object["name"],
            "size_bytes": len(target_payload),
            "sha256": hashlib.sha256(target_payload).hexdigest(),
            "chunk_count": target_object["chunk_count"],
        },
        "transfer": {
            "first_chunk_utc": iso8601(min(target_times)),
            "last_chunk_utc": iso8601(max(target_times)),
        },
    }
    expected = {
        "report": report,
        "archive_sha256": hashlib.sha256(target_payload).hexdigest(),
        "archive_size": len(target_payload),
    }
    (FIXTURE_DIR / "expected.json").write_text(json.dumps(expected, indent=2, sort_keys=True) + "\n")
    (FIXTURE_DIR / "expected_recovered.zip").write_bytes(target_payload)


if __name__ == "__main__":
    main()
