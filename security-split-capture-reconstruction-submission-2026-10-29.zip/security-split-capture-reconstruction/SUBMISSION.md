# Submission brief

**Category:** Security — Network Forensics

This is a self-contained incident-response reconstruction task. The agent
correlates complementary packet captures, NAT and clock records, TLS key-log
material, and a documented application protocol to recover a protected export
and a strict incident report. The verifier consumes only the saved artifacts;
it independently validates bytes, cryptographic digest, archive structure,
schema, session identity, and evidence-derived timestamps.

Run the submission gates from this directory:

```sh
python3 /path/to/frontierswe-check.py .
harbor run -p . -a oracle
harbor run -p . -a nop
```

All three gates are verified for the current contents (2026-10-29, Harbor
0.20.0): the checker reports PASS with no FAIL and no WARN lines, Oracle scores
`Mean: 1.000`, and NOP scores `Mean: 0.000`. The checker's PASS line, including
its content fingerprint, is recorded in
`../evaluation-sample-kit/VALIDATION.md`.
