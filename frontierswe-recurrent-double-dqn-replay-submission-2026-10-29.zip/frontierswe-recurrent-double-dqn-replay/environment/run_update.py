"""Replay the paused learner and save all post-update checkpoints."""
import json
import sys
from pathlib import Path

sys.path.insert(0, "/app/src")
from learner import resume

snapshot = json.loads(Path("/app/data/learner_snapshot.json").read_text())
result = resume(snapshot)
Path("/app/output").mkdir(parents=True, exist_ok=True)
Path("/app/output/batch_results.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
