Case IR-2026-0417 concerns a suspected outbound object transfer through the corporate
address-translation gateway.

The inside sensor records client addresses before NAT. The edge sensor records the same
connections after NAT. Their clocks are independent, and both sensors suffered different
capture gaps. Firewall records provide the authoritative pre-NAT/post-NAT tuple mapping.

The incident of interest is the unique NFX2 object manifest whose policy is `restricted`
and whose operation is `export`. Normal `public` or `internal` synchronization objects are
out of scope.

TLS session secrets use the standard NSS key-log format.
