# Recurrent Double-DQN replay continuation

You inherit a NumPy implementation of a recurrent Double-DQN learner that was paused immediately before three prioritized-replay updates. Its current output is not trustworthy. Repair the implementation under `/app/src` so that it resumes the checkpoint exactly and produces the required artifact.

`/app/CONTRACT.md` is normative. Read it completely before changing code: it specifies the network, recurrent-state boundaries, Double-DQN targets, Huber semi-gradient, replay-table behavior, AdamW resumption, target updates, and the outer replay-calibration derivative policy. The differentiation section is part of the required result, including all nine controls and the stated stop-gradient sites; do not replace it with an unrelated surrogate.

The synthetic checkpoint is `/app/data/learner_snapshot.json`. Keep its schema and the public entry point intact. Your program must write a regular UTF-8 JSON file at `/app/output/batch_results.json` with the exact schema required by the contract. Run it with:

```sh
python /app/run_update.py
```

You may rewrite the supplied learner modules or add small supporting modules beneath `/app/src`. Do not modify the checkpoint or contract. The four supplied cases deliberately exercise both dueling aggregations and both priority-reporting modes; a repair that works for only one ordinary checkpoint but mishandles the replay-calibration derivatives is incomplete.
