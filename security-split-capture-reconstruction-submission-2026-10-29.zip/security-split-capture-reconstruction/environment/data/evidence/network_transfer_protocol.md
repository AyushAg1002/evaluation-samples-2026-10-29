The retained sessions use TLS 1.3 with ALPN `h2`. HTTP/2 integers use network byte order.
The connection begins with the normal 24-byte HTTP/2 client preface. Each frame then has
the standard 9-byte HTTP/2 header: 24-bit payload length, 8-bit type, 8-bit flags, and a
31-bit stream ID. Object-transfer records are carried in DATA frames (type 0). Other frame
types are transport metadata.

Every object-transfer DATA payload begins with ASCII `NFX2`, followed by an 8-bit record
kind.

Manifest record (kind 1), in order:

* 16-byte object ID
* 8-bit policy code
* 8-bit operation code
* 32-bit total object size
* 16-bit chunk count
* 16-bit UTF-8 object-name length
* 32-byte SHA-256 digest
* object-name bytes

Chunk record (kind 2), in order:

* 16-byte object ID
* 32-bit destination offset
* 16-bit data length
* 32-bit CRC-32 of the chunk data
* chunk data

Policy codes are 1=`public`, 2=`internal`, and 3=`restricted`. Operation codes are
1=`sync` and 2=`export`. Chunk frames can be interleaved across streams and need not arrive
in object-offset order. Retransmitted TCP bytes are not additional application records.

For incident timestamps, first fit an affine transform from each sensor's calibration rows:
`sensor_epoch_s = slope * trusted_utc_epoch_s + intercept`. A chunk's observation time is
the corrected timestamp of the TCP segment containing the first byte of the TLS record
that carries its DATA frame. If that byte was captured by both sensors, use the earlier
corrected observation. Report the minimum and maximum observation times across the target
object's chunk frames.
