import json
import math
import os
import stat
from pathlib import Path

import pytest


_CONTAINER_APP_ROOT = Path("/app")
# Inside the task container /app is authoritative, so the environment cannot
# redirect the verifier; the override exists only for running these tests
# outside a container.
APP_ROOT = (
    _CONTAINER_APP_ROOT
    if _CONTAINER_APP_ROOT.is_dir()
    else Path(os.environ.get("TASK_TEST_APP_ROOT", "/app"))
)
RESULT_PATH = APP_ROOT / "output" / "batch_results.json"
FIXTURE_ROOT = Path(__file__).resolve().parent / "fixtures"
EXPECTED = json.loads((FIXTURE_ROOT / "expected.json").read_text(encoding="utf-8"))
CASE_IDS = ("mean-power", "max-raw", "mean-raw", "max-power")
# The correct artifact is ~240 KB. This ceiling keeps a runaway agent's output
# from being read into memory, so an oversized artifact scores 0 instead of
# exhausting the verifier.
MAX_RESULT_BYTES = 16 * 1024 * 1024


def no_duplicate_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise AssertionError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def reject_nonfinite(value):
    raise AssertionError(f"non-finite JSON value: {value}")


def assert_regular_result():
    metadata = RESULT_PATH.lstat()
    assert stat.S_ISREG(metadata.st_mode), "batch_results.json must be a regular file"
    assert not RESULT_PATH.is_symlink(), "batch_results.json must not be a symlink"
    assert metadata.st_size <= MAX_RESULT_BYTES, "batch_results.json is implausibly large"
    # A hard link has no link target, so resolve() alone would report an
    # in-/app path for bytes that live outside it.
    assert metadata.st_nlink == 1, "batch_results.json must not be a hard link"
    RESULT_PATH.resolve(strict=True).relative_to(APP_ROOT.resolve(strict=True))


def load_actual():
    assert_regular_result()
    return json.loads(
        RESULT_PATH.read_text(encoding="utf-8"),
        object_pairs_hook=no_duplicate_object,
        parse_constant=reject_nonfinite,
    )


def near(actual, expected, path=()):
    """Compare the whole contract, using the separately specified curvature tolerance."""
    if isinstance(expected, dict):
        assert isinstance(actual, dict), f"{'.'.join(path)} must be an object"
        assert set(actual) == set(expected), f"wrong keys at {'.'.join(path)}"
        for key in expected:
            near(actual[key], expected[key], path + (str(key),))
        return
    if isinstance(expected, list):
        assert isinstance(actual, list), f"{'.'.join(path)} must be an array"
        assert len(actual) == len(expected), f"wrong length at {'.'.join(path)}"
        for index, (actual_item, expected_item) in enumerate(zip(actual, expected)):
            near(actual_item, expected_item, path + (str(index),))
        return
    if isinstance(expected, bool) or isinstance(expected, str) or expected is None:
        assert actual == expected, f"wrong value at {'.'.join(path)}"
        return
    if isinstance(expected, int):
        assert isinstance(actual, int) and not isinstance(actual, bool), f"{'.'.join(path)} must be an integer"
        assert actual == expected, f"wrong integer at {'.'.join(path)}"
        return
    assert isinstance(actual, (int, float)) and not isinstance(actual, bool), f"{'.'.join(path)} must be numeric"
    assert math.isfinite(actual), f"{'.'.join(path)} must be finite"
    curvature = "curvature" in path
    absolute, relative = (2e-5, 2e-4) if curvature else (1e-6, 1e-5)
    assert abs(actual - expected) <= absolute + relative * abs(expected), f"wrong numeric value at {'.'.join(path)}"


def expected_case(case_id):
    return next(case for case in EXPECTED["cases"] if case["id"] == case_id)


def actual_case(actual, case_id):
    return next(case for case in actual["cases"] if case["id"] == case_id)


def test_result_is_a_regular_json_artifact():
    actual = load_actual()
    assert isinstance(actual, dict)


def test_top_level_and_case_schema_are_exact():
    actual = load_actual()
    assert set(actual) == {"cases"}
    assert isinstance(actual["cases"], list) and len(actual["cases"]) == len(CASE_IDS)
    assert tuple(case.get("id") for case in actual["cases"]) == CASE_IDS
    for case in actual["cases"]:
        assert set(case) == {"id", "updates", "meta"}
        assert isinstance(case["updates"], list) and len(case["updates"]) == 3
        assert set(case["meta"]) == {"validation_loss", "replay_loss", "hypergradient", "curvature"}


@pytest.mark.parametrize("case_id", CASE_IDS)
@pytest.mark.parametrize("update_index", range(3))
def test_each_replay_checkpoint(case_id, update_index):
    actual = load_actual()
    expected = expected_case(case_id)["updates"][update_index]
    near(actual_case(actual, case_id)["updates"][update_index], expected, (case_id, "updates", str(update_index)))


@pytest.mark.parametrize("case_id", CASE_IDS)
def test_calibration_outputs(case_id):
    actual = load_actual()
    near(actual_case(actual, case_id)["meta"], expected_case(case_id)["meta"], (case_id, "meta"))
