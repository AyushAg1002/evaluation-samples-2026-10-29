#!/usr/bin/env python3

import csv
import hashlib
import ipaddress
import json
import os
import struct
import zlib
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDFExpand


APP_ROOT = Path(os.environ.get("APP_ROOT", "/app"))
EVIDENCE_ROOT = APP_ROOT / "evidence"
OUTPUT_ARCHIVE = APP_ROOT / "recovered" / "exfiltrated.bin"
OUTPUT_REPORT = APP_ROOT / "incident_report.json"


def read_pcap(path, sensor):
    data = path.read_bytes()
    if len(data) < 24:
        raise ValueError(f"{path} is not a PCAP file")
    magic = data[:4]
    if magic == b"\xd4\xc3\xb2\xa1":
        endian = "<"
        scale = 1_000_000
    elif magic == b"\xa1\xb2\xc3\xd4":
        endian = ">"
        scale = 1_000_000
    else:
        raise ValueError(f"unsupported PCAP byte order in {path}")

    packets = []
    offset = 24
    while offset + 16 <= len(data):
        seconds, fraction, captured_length, _ = struct.unpack_from(f"{endian}IIII", data, offset)
        offset += 16
        frame = data[offset : offset + captured_length]
        offset += captured_length
        if len(frame) < 14 or frame[12:14] != b"\x08\x00":
            continue
        ip_offset = 14
        version_ihl = frame[ip_offset]
        if version_ihl >> 4 != 4:
            continue
        ip_header_length = (version_ihl & 0x0F) * 4
        if len(frame) < ip_offset + ip_header_length or frame[ip_offset + 9] != 6:
            continue
        source_ip = str(ipaddress.IPv4Address(frame[ip_offset + 12 : ip_offset + 16]))
        destination_ip = str(ipaddress.IPv4Address(frame[ip_offset + 16 : ip_offset + 20]))
        tcp_offset = ip_offset + ip_header_length
        if len(frame) < tcp_offset + 20:
            continue
        source_port, destination_port, sequence, acknowledgment = struct.unpack_from("!HHII", frame, tcp_offset)
        tcp_header_length = (frame[tcp_offset + 12] >> 4) * 4
        flags = frame[tcp_offset + 13]
        payload = frame[tcp_offset + tcp_header_length :]
        source_mac = ":".join(f"{byte:02x}" for byte in frame[6:12])
        packets.append(
            {
                "sensor": sensor,
                "sensor_time": seconds + fraction / scale,
                "src_ip": source_ip,
                "dst_ip": destination_ip,
                "src_port": source_port,
                "dst_port": destination_port,
                "seq": sequence,
                "ack": acknowledgment,
                "flags": flags,
                "payload": payload,
                "src_mac": source_mac,
            }
        )
    return packets


def load_clock_models(path):
    rows = list(csv.DictReader(path.open()))
    models = {}
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["sensor"]].append(
            (float(row["trusted_utc_epoch_s"]), float(row["sensor_epoch_s"]))
        )
    for sensor, points in grouped.items():
        points.sort()
        utc_start, sensor_start = points[0]
        utc_end, sensor_end = points[-1]
        slope = (sensor_end - sensor_start) / (utc_end - utc_start)
        models[sensor] = (utc_start, sensor_start, slope)
    return models


def corrected_time(packet, clock_models):
    utc_start, sensor_start, slope = clock_models[packet["sensor"]]
    return utc_start + (packet["sensor_time"] - sensor_start) / slope


def flow_matches(packet, mapping, sensor, direction):
    if sensor == "inside":
        client_ip = mapping["internal_ip"]
        client_port = int(mapping["internal_port"])
    else:
        client_ip = mapping["public_ip"]
        client_port = int(mapping["public_port"])
    server_ip = mapping["destination_ip"]
    server_port = int(mapping["destination_port"])
    if direction == "c2s":
        return (
            packet["src_ip"] == client_ip
            and packet["src_port"] == client_port
            and packet["dst_ip"] == server_ip
            and packet["dst_port"] == server_port
        )
    return (
        packet["src_ip"] == server_ip
        and packet["src_port"] == server_port
        and packet["dst_ip"] == client_ip
        and packet["dst_port"] == client_port
    )


def reassemble_client_stream(mapping, packets, clock_models):
    segments = {}
    victim_mac = None
    for packet in packets:
        if not packet["payload"]:
            continue
        if not flow_matches(packet, mapping, packet["sensor"], "c2s"):
            continue
        if packet["sensor"] == "inside":
            victim_mac = packet["src_mac"]
        sequence = packet["seq"]
        timestamp = corrected_time(packet, clock_models)
        existing = segments.get(sequence)
        if existing is None:
            segments[sequence] = (packet["payload"], timestamp)
        else:
            existing_payload, existing_timestamp = existing
            if existing_payload != packet["payload"]:
                raise ValueError(f"conflicting retransmission at TCP sequence {sequence}")
            segments[sequence] = (existing_payload, min(existing_timestamp, timestamp))
    if not segments:
        return None

    ordered = sorted((sequence, payload, timestamp) for sequence, (payload, timestamp) in segments.items())
    base_sequence = ordered[0][0]
    stream = bytearray()
    ranges = []
    cursor = base_sequence
    for sequence, payload, timestamp in ordered:
        if sequence > cursor:
            return None
        overlap = max(0, cursor - sequence)
        if overlap >= len(payload):
            continue
        if overlap and stream[sequence - base_sequence : sequence - base_sequence + overlap] != payload[:overlap]:
            raise ValueError(f"conflicting TCP overlap at sequence {sequence}")
        new_payload = payload[overlap:]
        start = len(stream)
        stream.extend(new_payload)
        ranges.append((start, len(stream), timestamp))
        cursor += len(new_payload)
    return bytes(stream), ranges, victim_mac


def sensor_provenance(mapping, packets, stream_length):
    """Count client-stream bytes by which sensors observed them.

    The captures have different gaps, so this is the accounting a single merged
    capture hides: every byte was seen by the inside sensor, the edge sensor, or
    both, and the two gap sets do not overlap.
    """
    client_packets = [
        packet
        for packet in packets
        if packet["payload"] and flow_matches(packet, mapping, packet["sensor"], "c2s")
    ]
    if not client_packets:
        return None
    base = min(packet["seq"] for packet in client_packets)
    observations = {}
    for packet in client_packets:
        start = packet["seq"] - base
        for offset in range(start, start + len(packet["payload"])):
            if 0 <= offset < stream_length:
                observations.setdefault(offset, set()).add(packet["sensor"])
    inside = {offset for offset, sensors in observations.items() if "inside" in sensors}
    edge = {offset for offset, sensors in observations.items() if "edge" in sensors}
    return {
        "client_stream_bytes": stream_length,
        "shared_bytes": len(inside & edge),
        "inside_only_bytes": len(inside - edge),
        "edge_only_bytes": len(edge - inside),
    }


def timestamp_for_offset(ranges, offset):
    for start, end, timestamp in ranges:
        if start <= offset < end:
            return timestamp
    raise ValueError(f"no packet timestamp for stream offset {offset}")


def parse_tls_records(stream, ranges):
    records = []
    offset = 0
    while offset + 5 <= len(stream):
        record_type = stream[offset]
        record_length = int.from_bytes(stream[offset + 3 : offset + 5], "big")
        end = offset + 5 + record_length
        if end > len(stream):
            raise ValueError("truncated TLS record")
        records.append(
            {
                "type": record_type,
                "header": stream[offset : offset + 5],
                "payload": stream[offset + 5 : end],
                "stream_offset": offset,
                "timestamp": timestamp_for_offset(ranges, offset),
            }
        )
        offset = end
    if offset != len(stream):
        raise ValueError("trailing bytes after TLS stream")
    return records


def parse_client_hello(records):
    for record in records:
        if record["type"] != 22:
            continue
        payload = record["payload"]
        if len(payload) < 4 or payload[0] != 1:
            continue
        body_length = int.from_bytes(payload[1:4], "big")
        body = payload[4 : 4 + body_length]
        if len(body) < 35:
            continue
        client_random = body[2:34].hex()
        cursor = 34
        session_id_length = body[cursor]
        cursor += 1 + session_id_length
        cipher_length = int.from_bytes(body[cursor : cursor + 2], "big")
        cursor += 2 + cipher_length
        compression_length = body[cursor]
        cursor += 1 + compression_length
        extensions_length = int.from_bytes(body[cursor : cursor + 2], "big")
        cursor += 2
        extensions_end = cursor + extensions_length
        sni = None
        while cursor + 4 <= extensions_end:
            extension_type = int.from_bytes(body[cursor : cursor + 2], "big")
            extension_length = int.from_bytes(body[cursor + 2 : cursor + 4], "big")
            extension = body[cursor + 4 : cursor + 4 + extension_length]
            cursor += 4 + extension_length
            if extension_type != 0 or len(extension) < 5:
                continue
            name_list_length = int.from_bytes(extension[:2], "big")
            if name_list_length + 2 > len(extension):
                continue
            name_type = extension[2]
            name_length = int.from_bytes(extension[3:5], "big")
            if name_type == 0 and 5 + name_length <= len(extension):
                sni = extension[5 : 5 + name_length].decode()
        if sni is None:
            raise ValueError("ClientHello did not contain SNI")
        return client_random, sni
    raise ValueError("ClientHello was not found")


def load_client_secrets(path):
    secrets = {}
    for line in path.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        label, client_random, secret = line.split()
        if label == "CLIENT_TRAFFIC_SECRET_0":
            secrets[client_random.lower()] = bytes.fromhex(secret)
    return secrets


def hkdf_expand_label(secret, label, length, algorithm):
    full_label = b"tls13 " + label
    info = struct.pack("!H", length) + bytes([len(full_label)]) + full_label + b"\x00"
    return HKDFExpand(algorithm=algorithm, length=length, info=info).derive(secret)


def decrypt_client_application(records, secret):
    if len(secret) == 48:
        algorithm = hashes.SHA384()
        key_length = 32
    elif len(secret) == 32:
        algorithm = hashes.SHA256()
        key_length = 16
    else:
        raise ValueError("unsupported TLS traffic-secret length")

    key = hkdf_expand_label(secret, b"key", key_length, algorithm)
    iv = hkdf_expand_label(secret, b"iv", 12, algorithm)
    cipher = AESGCM(key)
    sequence = 0
    started = False
    plaintext_records = []

    for record in records:
        if record["type"] != 23:
            continue
        nonce = bytes(left ^ right for left, right in zip(iv, sequence.to_bytes(12, "big")))
        try:
            decrypted = cipher.decrypt(nonce, record["payload"], record["header"])
        except Exception:
            if started:
                raise
            continue
        started = True
        sequence += 1
        unpadded = decrypted.rstrip(b"\x00")
        if not unpadded:
            continue
        inner_type = unpadded[-1]
        content = unpadded[:-1]
        if inner_type == 23 and content:
            plaintext_records.append((content, record["timestamp"]))
    if not plaintext_records:
        raise ValueError("no TLS application records decrypted")
    return plaintext_records


def frame_timestamp(ranges, offset):
    for start, end, timestamp in ranges:
        if start <= offset < end:
            return timestamp
    raise ValueError(f"no TLS record timestamp for HTTP/2 offset {offset}")


def parse_application_records(plaintext_records):
    stream = bytearray()
    ranges = []
    for content, timestamp in plaintext_records:
        start = len(stream)
        stream.extend(content)
        ranges.append((start, len(stream), timestamp))

    preface = b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n"
    if not stream.startswith(preface):
        raise ValueError("HTTP/2 client preface is missing")
    cursor = len(preface)
    manifests = {}
    chunks = defaultdict(list)
    chunk_times = defaultdict(list)
    manifest_format = "!4sB16sBBIHH32s"
    manifest_size = struct.calcsize(manifest_format)
    chunk_format = "!4sB16sIHI"
    chunk_header_size = struct.calcsize(chunk_format)

    while cursor + 9 <= len(stream):
        frame_start = cursor
        frame_length = int.from_bytes(stream[cursor : cursor + 3], "big")
        frame_type = stream[cursor + 3]
        stream_id = int.from_bytes(stream[cursor + 5 : cursor + 9], "big") & 0x7FFFFFFF
        cursor += 9
        payload = bytes(stream[cursor : cursor + frame_length])
        cursor += frame_length
        if frame_type != 0 or not payload.startswith(b"NFX2"):
            continue
        kind = payload[4]
        if kind == 1:
            if len(payload) < manifest_size:
                raise ValueError("truncated object manifest")
            (
                magic,
                _,
                object_id,
                policy,
                operation,
                total_size,
                chunk_count,
                name_length,
                digest,
            ) = struct.unpack_from(manifest_format, payload)
            name = payload[manifest_size : manifest_size + name_length].decode()
            manifests[object_id] = {
                "stream_id": stream_id,
                "policy": policy,
                "operation": operation,
                "total_size": total_size,
                "chunk_count": chunk_count,
                "sha256": digest.hex(),
                "name": name,
            }
        elif kind == 2:
            if len(payload) < chunk_header_size:
                raise ValueError("truncated object chunk")
            magic, _, object_id, offset, data_length, expected_crc = struct.unpack_from(chunk_format, payload)
            chunk = payload[chunk_header_size : chunk_header_size + data_length]
            if len(chunk) != data_length or zlib.crc32(chunk) != expected_crc:
                raise ValueError("invalid object-chunk CRC")
            chunks[object_id].append((offset, chunk))
            chunk_times[object_id].append(frame_timestamp(ranges, frame_start))
    return manifests, chunks, chunk_times


def reconstruct_object(manifest, chunks):
    output = bytearray(manifest["total_size"])
    covered = bytearray(manifest["total_size"])
    for offset, chunk in chunks:
        end = offset + len(chunk)
        if end > len(output):
            raise ValueError("chunk extends beyond declared object size")
        existing = output[offset:end]
        existing_covered = covered[offset:end]
        if any(existing_covered) and existing != chunk:
            raise ValueError("conflicting object chunks")
        output[offset:end] = chunk
        covered[offset:end] = b"\x01" * len(chunk)
    if not all(covered):
        raise ValueError("object reconstruction has gaps")
    digest = hashlib.sha256(output).hexdigest()
    if digest != manifest["sha256"]:
        raise ValueError("reconstructed object hash does not match manifest")
    return bytes(output)


def format_timestamp(timestamp):
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def main():
    clock_models = load_clock_models(EVIDENCE_ROOT / "sensor_clock_calibration.csv")
    packets = read_pcap(EVIDENCE_ROOT / "inside_sensor.pcap", "inside")
    packets.extend(read_pcap(EVIDENCE_ROOT / "edge_sensor.pcap", "edge"))
    mappings = list(csv.DictReader((EVIDENCE_ROOT / "firewall_nat.csv").open()))
    assets = {
        row["ip"]: row
        for row in csv.DictReader((EVIDENCE_ROOT / "asset_inventory.csv").open())
    }
    client_secrets = load_client_secrets(EVIDENCE_ROOT / "tls_session_keys.log")

    incident = None
    for mapping in mappings:
        reassembled = reassemble_client_stream(mapping, packets, clock_models)
        if reassembled is None:
            continue
        stream, ranges, victim_mac = reassembled
        tls_records = parse_tls_records(stream, ranges)
        client_random, sni = parse_client_hello(tls_records)
        secret = client_secrets.get(client_random)
        if secret is None:
            continue
        plaintext_records = decrypt_client_application(tls_records, secret)
        manifests, chunks, chunk_times = parse_application_records(plaintext_records)
        for object_id, manifest in manifests.items():
            if manifest["policy"] != 3 or manifest["operation"] != 2:
                continue
            recovered = reconstruct_object(manifest, chunks[object_id])
            times = chunk_times[object_id]
            asset = assets[mapping["internal_ip"]]
            incident = {
                "archive": recovered,
                "report": {
                    "case_id": "IR-2026-0417",
                    "victim": {
                        "ip": mapping["internal_ip"],
                        "mac": victim_mac,
                        "hostname": asset["hostname"],
                    },
                    "nat": {
                        "public_ip": mapping["public_ip"],
                        "public_port": int(mapping["public_port"]),
                    },
                    "destination": {
                        "ip": mapping["destination_ip"],
                        "port": int(mapping["destination_port"]),
                        "sni": sni,
                    },
                    "tls_client_random": client_random,
                    "object": {
                        "name": manifest["name"],
                        "size_bytes": manifest["total_size"],
                        "sha256": manifest["sha256"],
                        "chunk_count": manifest["chunk_count"],
                    },
                    "reassembly": sensor_provenance(mapping, packets, len(stream)),
                    "transfer": {
                        "first_chunk_utc": format_timestamp(min(times)),
                        "last_chunk_utc": format_timestamp(max(times)),
                        "chunk_utc": [format_timestamp(t) for t in sorted(times)],
                    },
                },
            }
    if incident is None:
        raise RuntimeError("restricted export object was not found")

    OUTPUT_ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_ARCHIVE.write_bytes(incident["archive"])
    OUTPUT_REPORT.write_text(json.dumps(incident["report"], indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
