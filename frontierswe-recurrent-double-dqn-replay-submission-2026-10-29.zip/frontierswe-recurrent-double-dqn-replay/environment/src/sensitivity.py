"""Checkpoint control coordinates and held-out calibration objective."""
import copy

import numpy as np

from recurrent import forward


def prepare(snapshot, case, controls):
    prepared = copy.deepcopy(snapshot)
    configured = copy.deepcopy(case)
    directions = snapshot["meta"]["directions"]
    for name in prepared["online"]:
        prepared["online"][name] = np.asarray(snapshot["online"][name]) + controls[3] * np.asarray(directions["online"][name])
        prepared["target"][name] = np.asarray(snapshot["target"][name]) + controls[7] * np.asarray(directions["target"][name])
        prepared["optimizer"]["m"][name] = np.asarray(snapshot["optimizer"]["m"][name]) + controls[4] * np.asarray(directions["m"][name])
    for name, segment in prepared["segments"].items():
        segment["rewards"] = np.asarray(segment["rewards"]) + controls[1] * np.asarray(directions["rewards"][name])
        for field in ("online_hidden", "target_hidden"):
            segment[field] = np.asarray(segment[field]) + controls[6] * np.asarray(directions[field][name])
        prepared["priorities"][name] *= np.exp(controls[5] * directions["priorities"][name])
    configured["config"]["lr"] *= np.exp(controls[0])
    configured["config"]["alpha"] += controls[2]
    gamma = case["config"]["gamma"]
    configured["config"]["gamma"] = 1 / (1 + np.exp(-np.log(gamma / (1 - gamma)) - controls[8]))
    return prepared, configured


def objective(parameters, snapshot, aggregation):
    total = 0.0
    count = 0
    for probe in snapshot["meta"]["validation"]:
        values, _ = forward(parameters, probe["observations"], probe["hidden"], aggregation)
        predictions = values[np.arange(len(probe["actions"])), probe["actions"]]
        total += np.sum((predictions - np.asarray(probe["returns"])) ** 2)
        count += len(probe["actions"])
    return total / count
