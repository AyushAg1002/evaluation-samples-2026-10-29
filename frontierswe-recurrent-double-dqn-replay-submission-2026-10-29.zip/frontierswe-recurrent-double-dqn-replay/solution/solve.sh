#!/bin/sh
set -eu

cp /solution/fixed/run_update.py /app/run_update.py
cp /solution/fixed/src/learner.py /app/src/learner.py
cp /solution/fixed/src/recurrent.py /app/src/recurrent.py
cp /solution/fixed/src/sensitivity.py /app/src/sensitivity.py
mkdir -p /app/output
python3 /app/run_update.py
