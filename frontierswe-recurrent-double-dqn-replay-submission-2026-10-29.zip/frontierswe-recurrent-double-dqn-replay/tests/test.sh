#!/bin/sh
set -eu

mkdir -p /logs/verifier

# -I isolates the interpreter: no user site-packages, no PYTHONPATH, no cwd on
# sys.path. Without it, a .pth file planted in the agent-writable user site runs
# arbitrary code inside this process before the tests are imported.
python3 -I -m pytest -p no:cacheprovider \
    --ctrf /logs/verifier/ctrf.json \
    --junit-xml=/logs/verifier/junit.xml \
    /tests/test_outputs.py -rA || true

# Reward is the fraction of content checks passed, gated on the artifact being
# structurally valid. The oracle still scores exactly 1.0 and a no-op exactly
# 0.0, but a 20-hour run that gets the checkpoints right and the second-order
# derivatives wrong is now distinguishable from one that produced nothing.
# JUnit XML is used rather than CTRF because CTRF collapses parametrised cases.
reward=$(python3 -I - <<'PY'
import xml.etree.ElementTree as ET

# Passing these proves only that a well-formed file of the right shape exists.
STRUCTURAL = (
    "test_result_is_a_regular_json_artifact",
    "test_top_level_and_case_schema_are_exact",
)


def passed(case):
    return not any(child.tag in ("failure", "error", "skipped") for child in case)


try:
    cases = list(ET.parse("/logs/verifier/junit.xml").getroot().iter("testcase"))
except Exception:
    print("0")
    raise SystemExit(0)

structural = [c for c in cases if c.get("name", "").split("[", 1)[0] in STRUCTURAL]
content = [c for c in cases if c.get("name", "").split("[", 1)[0] not in STRUCTURAL]

if not cases or not structural or not content or not all(map(passed, structural)):
    print("0")
else:
    print(f"{sum(map(passed, content)) / len(content):.6f}")
PY
) || reward=0

printf '%s\n' "${reward:-0}" > /logs/verifier/reward.txt
