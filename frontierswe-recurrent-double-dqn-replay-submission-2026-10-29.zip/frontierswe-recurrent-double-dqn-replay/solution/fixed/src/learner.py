"""Resume a recurrent replay learner from an explicit checkpoint."""
import numpy as np

from recurrent import backward, forward
from sensitivity import objective, prepare


def clipped(values, threshold):
    return np.where(values.real < -threshold, -threshold, np.where(values.real > threshold, threshold, values))


def targets_for(segment, online_values, target_values, config, barriers=None, record=None):
    returns = []
    for start in range(segment["burn_in"], segment["burn_in"] + segment["learn_length"]):
        total = 0.0
        discount = 1.0
        for position in range(start, min(start + config["n_step"], len(segment["rewards"]))):
            total += discount * clipped(segment["rewards"][position], config["reward_clip"])
            discount *= config["gamma"]
            if segment["terminated"][position] or segment["truncated"][position]:
                break
        bootstrap = 0.0
        if not segment["terminated"][position]:
            allowed = sorted(segment["legal_actions"][position])
            selected = allowed[int(np.argmax(online_values[position + 1, allowed].real))]
            bootstrap = target_values[position + 1, selected].real if barriers is None else barriers[len(returns)]
            total += discount * bootstrap
        if record is not None:
            record.append(float(bootstrap))
        returns.append(total)
    return np.array(returns)


def tensors(values):
    return {name: np.array(value, dtype=np.complex128 if np.iscomplexobj(value) else np.float64) for name, value in values.items()}


def serialize(values):
    return {name: value.tolist() for name, value in values.items()}


def run_case(snapshot, case, controls=None, trace=None, barriers=None, record=None):
    if controls is not None:
        snapshot, case = prepare(snapshot, case, controls)
    online = tensors(snapshot["online"])
    target = tensors(snapshot["target"])
    first_moment = tensors(snapshot["optimizer"]["m"])
    second_moment = tensors(snapshot["optimizer"]["v"])
    step = snapshot["optimizer"]["step"]
    priorities = dict(snapshot["priorities"])
    config = case["config"]
    aggregation = config["advantage_aggregation"]
    updates = []
    prefix = 0.0
    for batch_index, batch in enumerate(case["batches"]):
        stop_values = None if barriers is None else barriers[batch_index]
        recorded = None if record is None else {"bootstrap": []}
        baseline = objective(online, snapshot, aggregation) / len(case["batches"])
        normalizer = np.log(sum(value**config["alpha"] for value in priorities.values()))
        prefix += sum(config["alpha"] * np.log(priorities[name]) - normalizer for name in batch)
        raw_weights = np.array([priorities[name] ** (-config["alpha"] * config["beta"]) for name in batch])
        denominator = raw_weights[np.argmax(raw_weights.real)].real if stop_values is None else stop_values["weight_denominator"]
        weights = raw_weights / denominator
        if recorded is not None:
            recorded["weight_denominator"] = float(denominator)
            recorded["score_prefix"] = float(prefix)
        gradients = {name: np.zeros_like(value) for name, value in online.items()}
        draws = []
        replacements = {}
        loss = 0.0
        for ordinal, sequence_id in enumerate(batch):
            segment = snapshot["segments"][sequence_id]
            online_values, cache = forward(online, segment["observations"], segment["online_hidden"], aggregation)
            target_values, _ = forward(target, segment["observations"], segment["target_hidden"], aggregation)
            bootstrap_record = None if recorded is None else []
            returns = targets_for(
                segment,
                online_values,
                target_values,
                config,
                None if stop_values is None else stop_values["bootstrap"][ordinal],
                bootstrap_record,
            )
            if recorded is not None:
                recorded["bootstrap"].append(bootstrap_record)
            start = segment["burn_in"]
            stop = start + segment["learn_length"]
            predictions = online_values[np.arange(start, stop), segment["actions"][start:stop]]
            errors = returns - predictions
            absolute = np.sign(errors.real) * errors
            threshold = config["huber_delta"]
            huber = np.where(absolute.real <= threshold, 0.5 * errors**2, threshold * (absolute - 0.5 * threshold))
            loss += weights[ordinal] * huber.mean() / len(batch)
            derivatives = -clipped(errors, threshold) * weights[ordinal] / (len(batch) * len(errors))
            draw_gradients = backward(online, cache, start, stop, segment["actions"], derivatives, aggregation)
            for name in gradients:
                gradients[name] += draw_gradients[name]
            raw = config["priority_epsilon"] + config["priority_mix"] * absolute[np.argmax(absolute.real)] + (1 - config["priority_mix"]) * absolute.mean()
            if sequence_id not in replacements or raw.real > replacements[sequence_id].real:
                replacements[sequence_id] = raw.item()
            draws.append({
                "draw": ordinal, "sequence_id": sequence_id,
                "n_step_return": returns.tolist(), "td_error": errors.tolist(),
                "is_weight": weights[ordinal].item(),
                "new_priority": (raw**config["alpha"] if config["priority_power"] else raw).item(),
            })
        norm = np.sqrt(sum(np.sum(value * value) for value in gradients.values())).item()
        scale = min(1.0, config["grad_clip"] / np.real(norm)) if np.real(norm) else 1.0
        if stop_values is not None:
            scale = stop_values["clip_factor"]
        if recorded is not None:
            recorded["clip_factor"] = float(scale)
            record.append(recorded)
        step += 1
        for name in online:
            gradient = gradients[name] * scale
            first_moment[name] = config["beta1"] * first_moment[name] + (1 - config["beta1"]) * gradient
            second_moment[name] = config["beta2"] * second_moment[name] + (1 - config["beta2"]) * gradient**2
            corrected_first = first_moment[name] / (1 - config["beta1"]**step)
            corrected_second = second_moment[name] / (1 - config["beta2"]**step)
            online[name] = (1 - config["lr"] * config["weight_decay"]) * online[name] - config["lr"] * corrected_first / (np.sqrt(corrected_second) + config["adam_epsilon"])
        if step % config["target_interval"] == 0:
            target = {name: (1 - config["tau"]) * target[name] + config["tau"] * online[name] for name in target}
        priorities.update(replacements)
        if trace is not None:
            trace.append({"prefix": prefix, "baseline": baseline,
                          "cost": objective(online, snapshot, aggregation) / len(case["batches"])})
        updates.append({
            "step": step, "draws": draws, "loss": loss.item(), "gradient_norm": norm,
            "online": serialize(online), "target": serialize(target),
            "optimizer": {"step": step, "m": serialize(first_moment), "v": serialize(second_moment)},
            "priorities": dict(priorities),
        })
    return {"id": case["id"], "updates": updates}, objective(online, snapshot, aggregation)


def replay_objective(snapshot, case, controls, tape):
    trace = []
    run_case(snapshot, case, controls, trace=trace, barriers=tape)
    result = 0.0
    previous = 1.0
    for stage, stopped in zip(trace, tape):
        multiplier = np.exp(stage["prefix"] - stopped["score_prefix"])
        result += multiplier * stage["cost"] + (previous - multiplier) * stage["baseline"]
        previous = multiplier
    return result


def replay_gradient(snapshot, case, controls, tape):
    gradient = []
    for index in range(len(controls)):
        shifted = np.array(controls, dtype=np.complex128)
        shifted[index] += 1e-24j
        gradient.append(float(replay_objective(snapshot, case, shifted, tape).imag / 1e-24))
    return np.array(gradient)


def resume(snapshot):
    cases = []
    order = snapshot["meta"]["control_order"]
    for case in snapshot["cases"]:
        tape = []
        trace = []
        result, value = run_case(snapshot, case, trace=trace, record=tape)
        controls = np.zeros(len(order))
        gradient = replay_gradient(snapshot, case, controls, tape)
        curvature = {}
        for name, vector in snapshot["meta"]["curvature_directions"].items():
            approximations = []
            for step in (4e-4, 2e-4):
                shift = step * np.asarray(vector)
                plus = replay_gradient(snapshot, case, shift, tape)
                minus = replay_gradient(snapshot, case, -shift, tape)
                approximations.append((plus - minus) / (2 * step))
            curvature[name] = ((4 * approximations[1] - approximations[0]) / 3).tolist()
        result["meta"] = {
            "validation_loss": float(value), "replay_loss": float(sum(stage["cost"] for stage in trace)),
            "hypergradient": dict(zip(order, gradient.tolist())), "curvature": curvature,
        }
        cases.append(result)
    return {"cases": cases}
